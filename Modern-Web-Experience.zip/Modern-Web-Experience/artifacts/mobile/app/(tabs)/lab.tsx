import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { ActionButton, BodyText, Heading, Kicker, Page, Panel } from '@/components/AcademyUI';
import { useColors } from '@/hooks/useColors';

type LabMode = 'prompt' | 'agent' | 'ethics';
const labTabs: { id: LabMode; label: string }[] = [
  { id: 'prompt', label: 'Prompt' },
  { id: 'agent', label: 'Agenti' },
  { id: 'ethics', label: 'Bias' },
];
const workflowSteps = [
  { id: 'trigger', label: 'Trigger', detail: 'Arriva una nuova richiesta', icon: 'lightning-bolt' },
  { id: 'ai', label: 'Azione AI', detail: 'Classifica e prepara una bozza', icon: 'creation' },
  { id: 'review', label: 'Revisione', detail: 'Una persona controlla il risultato', icon: 'account-check-outline' },
  { id: 'output', label: 'Output', detail: 'La richiesta viene instradata', icon: 'send-outline' },
];
const biasCases = [
  { title: 'Selezione CV', groupA: 'Gruppo A', rateA: 72, groupB: 'Gruppo B', rateB: 48, advice: 'Rivedi le etichette storiche, testa le differenze per ruolo e valuta criteri di selezione pertinenti al lavoro.' },
  { title: 'Accesso al credito', groupA: 'Area urbana', rateA: 68, groupB: 'Area rurale', rateB: 52, advice: 'Controlla se le variabili geografiche sono proxy, confronta tassi di errore e aggiungi un percorso di ricorso.' },
  { title: 'Priorità sanitaria', groupA: 'Fascia 1', rateA: 81, groupB: 'Fascia 2', rateB: 57, advice: 'Coinvolgi professionisti clinici, verifica la qualità delle etichette e non usare l’esempio come criterio diagnostico.' },
];

export default function PracticeLab() {
  const colors = useColors();
  const [mode, setMode] = useState<LabMode>('prompt');
  const [prompt, setPrompt] = useState('Spiega come funziona un Transformer a un team non tecnico.');
  const [temperature, setTemperature] = useState(0.4);
  const [topP, setTopP] = useState(0.9);
  const [output, setOutput] = useState('');
  const [steps, setSteps] = useState(['trigger', 'ai', 'review', 'output']);
  const [workflowResult, setWorkflowResult] = useState('');
  const [biasIndex, setBiasIndex] = useState(0);
  const sample = biasCases[biasIndex];

  function runPrompt() {
    const style = temperature < 0.35 ? 'diretto e consistente' : temperature > 0.7 ? 'vario e creativo' : 'equilibrato';
    const focus = topP < 0.55 ? 'restando vicino alle formulazioni più probabili' : 'considerando una gamma più ampia di formulazioni';
    setOutput(`Simulazione locale · stile ${style}, top-p ${topP.toFixed(1)}.\n\nPer la richiesta “${prompt.trim() || 'Inserisci una richiesta'}”, il sistema produrrebbe una risposta iniziale ${focus}. Verifica sempre i fatti e aggiungi fonti quando la precisione è importante.`);
  }

  function addStep() {
    const available = workflowSteps.find((step) => !steps.includes(step.id));
    if (available) setSteps((current) => [...current, available.id]);
  }

  return (
    <Page>
      <Kicker>SPAZIO DI SPERIMENTAZIONE</Kicker>
      <Heading subtitle="Prova i concetti del corso in un ambiente didattico e locale.">Laboratorio pratico</Heading>
      <View style={[styles.tabRail, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {labTabs.map((tab) => (
          <Pressable
            key={tab.id}
            testID={`lab-${tab.id}`}
            accessibilityRole="button"
            onPress={() => setMode(tab.id)}
            style={[styles.tabButton, mode === tab.id && { backgroundColor: colors.primary }]}
          >
            <Text style={[styles.tabText, { color: mode === tab.id ? colors.primaryForeground : colors.mutedForeground }]}>{tab.label}</Text>
          </Pressable>
        ))}
      </View>

      {mode === 'prompt' ? (
        <>
          <Panel style={styles.panel}>
            <View style={styles.panelHeader}>
              <View style={[styles.iconBox, { backgroundColor: colors.accent }]}>
                <MaterialCommunityIcons name="message-text-outline" size={20} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.panelTitle, { color: colors.foreground }]}>Prompt playground</Text>
                <Text style={[styles.panelSub, { color: colors.mutedForeground }]}>Esplora le impostazioni di generazione</Text>
              </View>
            </View>
            <Text style={[styles.inputLabel, { color: colors.secondaryForeground }]}>LA TUA RICHIESTA</Text>
            <TextInput
              testID="prompt-input"
              value={prompt}
              onChangeText={setPrompt}
              multiline
              textAlignVertical="top"
              placeholder="Scrivi una richiesta da esplorare"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.textArea, { color: colors.foreground, backgroundColor: colors.background, borderColor: colors.border }]}
            />
            <View style={styles.sliderBlock}>
              <View style={styles.sliderHeader}>
                <Text style={[styles.inputLabel, { color: colors.secondaryForeground }]}>TEMPERATURA</Text>
                <Text style={[styles.sliderValue, { color: colors.primary }]}>{temperature.toFixed(1)}</Text>
              </View>
              <View style={styles.stepper}>
                <Pressable accessibilityRole="button" testID="temperature-down" onPress={() => setTemperature((value) => Math.max(0, Math.round((value - 0.1) * 10) / 10))} style={[styles.stepButton, { backgroundColor: colors.secondary }]}>
                  <MaterialCommunityIcons name="minus" size={19} color={colors.foreground} />
                </Pressable>
                <Text style={[styles.rangeCaption, { color: colors.mutedForeground }]}>Più deterministico</Text>
                <Text style={[styles.rangeCaption, { color: colors.mutedForeground }]}>Più vario</Text>
                <Pressable accessibilityRole="button" testID="temperature-up" onPress={() => setTemperature((value) => Math.min(1, Math.round((value + 0.1) * 10) / 10))} style={[styles.stepButton, { backgroundColor: colors.secondary }]}>
                  <MaterialCommunityIcons name="plus" size={19} color={colors.foreground} />
                </Pressable>
              </View>
              <View style={styles.sliderHeader}>
                <Text style={[styles.inputLabel, { color: colors.secondaryForeground }]}>TOP-P</Text>
                <Text style={[styles.sliderValue, { color: colors.primary }]}>{topP.toFixed(1)}</Text>
              </View>
              <View style={styles.stepper}>
                <Pressable accessibilityRole="button" testID="top-p-down" onPress={() => setTopP((value) => Math.max(0.1, Math.round((value - 0.1) * 10) / 10))} style={[styles.stepButton, { backgroundColor: colors.secondary }]}>
                  <MaterialCommunityIcons name="minus" size={19} color={colors.foreground} />
                </Pressable>
                <Text style={[styles.rangeCaption, { color: colors.mutedForeground }]}>Scelte ristrette</Text>
                <Text style={[styles.rangeCaption, { color: colors.mutedForeground }]}>Più alternative</Text>
                <Pressable accessibilityRole="button" testID="top-p-up" onPress={() => setTopP((value) => Math.min(1, Math.round((value + 0.1) * 10) / 10))} style={[styles.stepButton, { backgroundColor: colors.secondary }]}>
                  <MaterialCommunityIcons name="plus" size={19} color={colors.foreground} />
                </Pressable>
              </View>
            </View>
            <ActionButton label="Simula una risposta" onPress={runPrompt} testID="run-prompt" />
          </Panel>
          {output ? (
            <Panel style={styles.resultPanel}>
              <Kicker>OUTPUT DIMOSTRATIVO</Kicker>
              <BodyText>{output}</BodyText>
              <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>Esempio simulato: non è stata interrogata un’AI esterna.</Text>
            </Panel>
          ) : null}
        </>
      ) : null}

      {mode === 'agent' ? (
        <>
          <Panel style={styles.panel}>
            <View style={styles.panelHeader}>
              <View style={[styles.iconBox, { backgroundColor: colors.accent }]}>
                <MaterialCommunityIcons name="transit-connection-variant" size={20} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.panelTitle, { color: colors.foreground }]}>Costruisci un flusso</Text>
                <Text style={[styles.panelSub, { color: colors.mutedForeground }]}>Seleziona i blocchi e osserva la sequenza</Text>
              </View>
            </View>
            {steps.map((stepId, index) => {
              const step = workflowSteps.find((item) => item.id === stepId);
              if (!step) return null;
              return (
                <View key={`${stepId}-${index}`} style={styles.workflowRow}>
                  <View style={[styles.flowIcon, { backgroundColor: colors.accent }]}>
                    <MaterialCommunityIcons name={step.icon as any} size={17} color={colors.primary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.flowLabel, { color: colors.foreground }]}>{step.label}</Text>
                    <Text style={[styles.flowDetail, { color: colors.mutedForeground }]}>{step.detail}</Text>
                  </View>
                  {steps.length > 1 ? (
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel={`Rimuovi ${step.label}`}
                      testID={`remove-${stepId}-${index}`}
                      onPress={() => setSteps((current) => current.filter((_, itemIndex) => itemIndex !== index))}
                      hitSlop={8}
                    >
                      <MaterialCommunityIcons name="close-circle-outline" size={20} color={colors.mutedForeground} />
                    </Pressable>
                  ) : null}
                </View>
              );
            })}
            <ActionButton label="Aggiungi passaggio" variant="secondary" disabled={steps.length >= workflowSteps.length} onPress={addStep} />
            <ActionButton label="Esegui flusso di prova" onPress={() => setWorkflowResult(`Sequenza pronta: ${steps.map((id) => workflowSteps.find((step) => step.id === id)?.label).filter(Boolean).join(' → ')}.`)} />
            {workflowResult ? <Text style={[styles.workflowOutput, { color: colors.primary }]}>{workflowResult}</Text> : null}
          </Panel>
          <Panel>
            <Kicker>PRINCIPIO DI PROGETTAZIONE</Kicker>
            <BodyText>Per azioni esterne o difficili da annullare, inserisci una revisione umana e limita i permessi dell’agente.</BodyText>
          </Panel>
        </>
      ) : null}

      {mode === 'ethics' ? (
        <>
          <Panel style={styles.panel}>
            <View style={styles.panelHeader}>
              <View style={[styles.iconBox, { backgroundColor: colors.accent }]}>
                <MaterialCommunityIcons name="scale-balance" size={20} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.panelTitle, { color: colors.foreground }]}>Analizzatore di bias</Text>
                <Text style={[styles.panelSub, { color: colors.mutedForeground }]}>Confronta esiti su un esempio sintetico</Text>
              </View>
            </View>
            <Text style={[styles.inputLabel, { color: colors.secondaryForeground }]}>SCENARIO DIDATTICO</Text>
            <View style={styles.caseList}>
              {biasCases.map((item, index) => (
                <Pressable
                  key={item.title}
                  testID={`bias-case-${index}`}
                  accessibilityRole="button"
                  onPress={() => setBiasIndex(index)}
                  style={[styles.caseChip, { backgroundColor: biasIndex === index ? colors.primary : colors.secondary }]}
                >
                  <Text style={[styles.caseText, { color: biasIndex === index ? colors.primaryForeground : colors.secondaryForeground }]}>{item.title}</Text>
                </Pressable>
              ))}
            </View>
            <View style={[styles.metricBox, { backgroundColor: colors.background, borderColor: colors.border }]}>
              <Text style={[styles.metricTitle, { color: colors.foreground }]}>Esiti simulati · tasso di selezione</Text>
              <View style={styles.metricRow}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.flowDetail, { color: colors.mutedForeground }]}>{sample.groupA}</Text>
                  <Text style={[styles.metricValue, { color: colors.foreground }]}>{sample.rateA}%</Text>
                  <View style={[styles.metricTrack, { backgroundColor: colors.muted }]}><View style={[styles.metricFill, { width: `${sample.rateA}%`, backgroundColor: colors.primary }]} /></View>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.flowDetail, { color: colors.mutedForeground }]}>{sample.groupB}</Text>
                  <Text style={[styles.metricValue, { color: colors.foreground }]}>{sample.rateB}%</Text>
                  <View style={[styles.metricTrack, { backgroundColor: colors.muted }]}><View style={[styles.metricFill, { width: `${sample.rateB}%`, backgroundColor: colors.destructive }]} /></View>
                </View>
              </View>
              <Text style={[styles.gapText, { color: colors.destructive }]}>Differenza osservata: {Math.abs(sample.rateA - sample.rateB)} punti percentuali</Text>
            </View>
            <View style={[styles.adviceBox, { backgroundColor: colors.accent }]}>
              <Text style={[styles.adviceTitle, { color: colors.primary }]}>Prossimo controllo</Text>
              <BodyText>{sample.advice}</BodyText>
            </View>
            <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>Dati inventati a scopo formativo: non descrivono persone o sistemi reali e non dimostrano da soli una discriminazione.</Text>
          </Panel>
        </>
      ) : null}
    </Page>
  );
}

const styles = StyleSheet.create({
  tabRail: { flexDirection: 'row', borderWidth: 1, borderRadius: 16, padding: 4, marginBottom: 14 },
  tabButton: { flex: 1, alignItems: 'center', justifyContent: 'center', borderRadius: 12, paddingVertical: 10 },
  tabText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  panel: { gap: 14 },
  panelHeader: { flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 3 },
  iconBox: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  panelTitle: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  panelSub: { fontFamily: 'Inter_400Regular', fontSize: 11, marginTop: 3 },
  inputLabel: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.1 },
  textArea: { minHeight: 96, borderWidth: 1, borderRadius: 15, padding: 12, fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 20 },
  sliderBlock: { gap: 10 },
  sliderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sliderValue: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  stepper: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 5 },
  stepButton: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center', borderRadius: 11 },
  rangeCaption: { fontFamily: 'Inter_400Regular', fontSize: 9 },
  resultPanel: { gap: 9 },
  disclaimer: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17 },
  workflowRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 7 },
  flowIcon: { height: 35, width: 35, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  flowLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  flowDetail: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 16, marginTop: 3 },
  workflowOutput: { fontFamily: 'Inter_600SemiBold', fontSize: 13, lineHeight: 20 },
  caseList: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  caseChip: { borderRadius: 20, paddingHorizontal: 11, paddingVertical: 8 },
  caseText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  metricBox: { padding: 13, borderRadius: 15, borderWidth: 1, gap: 12 },
  metricTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  metricRow: { flexDirection: 'row', gap: 15 },
  metricValue: { fontFamily: 'Inter_700Bold', fontSize: 20, marginTop: 3 },
  metricTrack: { height: 6, borderRadius: 6, overflow: 'hidden', marginTop: 7 },
  metricFill: { height: '100%', borderRadius: 6 },
  gapText: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  adviceBox: { borderRadius: 15, padding: 13, gap: 7 },
  adviceTitle: { fontFamily: 'Inter_700Bold', fontSize: 12 },
});
