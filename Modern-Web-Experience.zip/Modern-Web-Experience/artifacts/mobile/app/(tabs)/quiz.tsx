import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { ActionButton, BodyText, Chip, Heading, Kicker, Page, Panel, ProgressBar } from '@/components/AcademyUI';
import { getDailyQuestions } from '@/data/course';
import { useAcademy } from '@/state/AcademyContext';
import { useColors } from '@/hooks/useColors';

function localDateKey() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

export default function DailyQuiz() {
  const colors = useColors();
  const dateKey = useMemo(localDateKey, []);
  const questions = useMemo(() => getDailyQuestions(dateKey), [dateKey]);
  const { dailyRecords, answerDaily } = useAcademy();
  const answers = dailyRecords[dateKey] ?? {};
  const firstUnanswered = questions.find((question) => !answers[question.id]);
  const [currentId, setCurrentId] = useState<string | null>(firstUnanswered?.id ?? null);

  useEffect(() => {
    if (!currentId && firstUnanswered) setCurrentId(firstUnanswered.id);
  }, [currentId, firstUnanswered]);

  const current = questions.find((question) => question.id === currentId) ?? firstUnanswered;
  const currentAnswer = current ? answers[current.id] : undefined;
  const correctCount = Object.values(answers).filter((answer) => answer.correct).length;
  const done = questions.every((question) => Boolean(answers[question.id]));
  const history = Object.entries(dailyRecords).sort(([a], [b]) => b.localeCompare(a)).slice(0, 7);

  function nextQuestion() {
    if (!current) return;
    const next = questions.find((question) => !answers[question.id] && question.id !== current.id);
    setCurrentId(next?.id ?? null);
  }

  return (
    <Page>
      <Kicker>ALLENAMENTO QUOTIDIANO</Kicker>
      <Heading subtitle="Cinque domande pratiche, un po’ di AI ogni giorno.">Quiz del giorno</Heading>
      <Panel style={styles.scorePanel}>
        <View style={styles.scoreTop}>
          <View>
            <Text style={[styles.scoreLabel, { color: colors.mutedForeground }]}>PUNTEGGIO DI OGGI</Text>
            <Text style={[styles.score, { color: colors.foreground }]}>{correctCount}<Text style={[styles.scoreTotal, { color: colors.mutedForeground }]}> / 5</Text></Text>
          </View>
          <View style={[styles.streakIcon, { backgroundColor: colors.accent }]}>
            <MaterialCommunityIcons name="lightning-bolt" size={22} color={colors.primary} />
          </View>
        </View>
        <ProgressBar value={(Object.keys(answers).length / questions.length) * 100} label="Domande completate" />
      </Panel>

      {current ? (
        <Panel>
          <View style={styles.questionMeta}>
            <Chip>DOMANDA {questions.findIndex((question) => question.id === current.id) + 1} / 5</Chip>
            <Text style={[styles.reward, { color: colors.primary }]}>+10 XP</Text>
          </View>
          <Text style={[styles.question, { color: colors.foreground }]}>{current.prompt}</Text>
          <View style={{ gap: 8, marginTop: 18 }}>
            {current.options.map((option, index) => {
              const isSelected = currentAnswer?.choice === index;
              const isCorrect = current.answer === index;
              const optionColor = currentAnswer
                ? isCorrect ? colors.primary : isSelected ? colors.destructive : colors.border
                : colors.border;
              return (
                <Pressable
                  key={`${current.id}-${option}`}
                  testID={`answer-${current.id}-${index}`}
                  accessibilityRole="button"
                  disabled={Boolean(currentAnswer)}
                  onPress={() => answerDaily(dateKey, current.id, index, index === current.answer)}
                  style={({ pressed }) => [
                    styles.option,
                    { borderColor: optionColor, backgroundColor: isSelected || (currentAnswer && isCorrect) ? colors.accent : colors.background, opacity: pressed ? 0.75 : 1 },
                  ]}
                >
                  <View style={[styles.optionLetter, { backgroundColor: isSelected || (currentAnswer && isCorrect) ? colors.primary : colors.muted }]}>
                    <Text style={[styles.optionLetterText, { color: isSelected || (currentAnswer && isCorrect) ? colors.primaryForeground : colors.mutedForeground }]}>{String.fromCharCode(65 + index)}</Text>
                  </View>
                  <Text style={[styles.optionText, { color: colors.foreground }]}>{option}</Text>
                  {currentAnswer && isCorrect ? <MaterialCommunityIcons name="check-circle" size={20} color={colors.primary} /> : null}
                </Pressable>
              );
            })}
          </View>
          {currentAnswer ? (
            <View style={[styles.feedback, { backgroundColor: currentAnswer.correct ? colors.accent : colors.muted }]}>
              <Text style={[styles.feedbackTitle, { color: currentAnswer.correct ? colors.primary : colors.destructive }]}>
                {currentAnswer.correct ? 'Esatto · +10 XP' : 'Non questa volta'}
              </Text>
              <BodyText>{current.explanation}</BodyText>
              <ActionButton label={questions.every((question) => Boolean(answers[question.id])) ? 'Vedi il riepilogo' : 'Prossima domanda'} onPress={nextQuestion} />
            </View>
          ) : null}
        </Panel>
      ) : (
        <Panel style={styles.donePanel}>
          <View style={[styles.doneIcon, { backgroundColor: colors.accent }]}>
            <MaterialCommunityIcons name={done ? 'check-decagram' : 'calendar-check'} size={27} color={colors.primary} />
          </View>
          <Heading subtitle={done ? `Hai risposto a tutte le domande e guadagnato ${correctCount * 10} XP.` : 'Torna domani per un nuovo set di domande.'}>
            {done ? 'Quiz completato' : 'Nessuna domanda disponibile'}
          </Heading>
          {done ? <Chip active>{correctCount} / 5 corrette</Chip> : null}
        </Panel>
      )}

      <View style={styles.historyHead}>
        <Kicker>IL TUO ARCHIVIO</Kicker>
        <Text style={[styles.historyTitle, { color: colors.foreground }]}>Quiz recenti</Text>
      </View>
      {history.length ? history.map(([date, dayAnswers]) => {
        const count = Object.values(dayAnswers).filter((answer) => answer.correct).length;
        return (
          <View key={date} style={[styles.historyRow, { borderColor: colors.border }]}>
            <View style={[styles.historyDot, { backgroundColor: colors.primary }]} />
            <Text style={[styles.historyDate, { color: colors.secondaryForeground }]}>{date}</Text>
            <Text style={[styles.historyScore, { color: colors.mutedForeground }]}>{count} / {Object.keys(dayAnswers).length} corrette</Text>
          </View>
        );
      }) : (
        <Text style={[styles.emptyHistory, { color: colors.mutedForeground }]}>Il tuo primo risultato apparirà qui.</Text>
      )}
    </Page>
  );
}

const styles = StyleSheet.create({
  scorePanel: { gap: 17 },
  scoreTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  scoreLabel: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.2 },
  score: { fontFamily: 'Inter_700Bold', fontSize: 32, marginTop: 4 },
  scoreTotal: { fontFamily: 'Inter_500Medium', fontSize: 17 },
  streakIcon: { width: 45, height: 45, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  questionMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  reward: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  question: { fontFamily: 'Inter_700Bold', fontSize: 19, lineHeight: 27, marginTop: 18 },
  option: { minHeight: 53, borderWidth: 1, borderRadius: 15, paddingHorizontal: 11, paddingVertical: 9, flexDirection: 'row', alignItems: 'center', gap: 10 },
  optionLetter: { width: 28, height: 28, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  optionLetterText: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  optionText: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 13, lineHeight: 18 },
  feedback: { padding: 13, borderRadius: 15, gap: 10, marginTop: 14 },
  feedbackTitle: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  donePanel: { alignItems: 'flex-start', gap: 10, paddingVertical: 21 },
  doneIcon: { width: 52, height: 52, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  historyHead: { marginTop: 17, marginBottom: 8 },
  historyTitle: { fontFamily: 'Inter_700Bold', fontSize: 18, marginTop: 5 },
  historyRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth, gap: 9 },
  historyDot: { width: 7, height: 7, borderRadius: 4 },
  historyDate: { fontFamily: 'Inter_600SemiBold', fontSize: 12, flex: 1 },
  historyScore: { fontFamily: 'Inter_400Regular', fontSize: 12 },
  emptyHistory: { fontFamily: 'Inter_400Regular', fontSize: 13, paddingVertical: 14 },
});
