import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { ActionButton, BodyText, Chip, Heading, Kicker, Page, Panel, ProgressBar } from '@/components/AcademyUI';
import { modules } from '@/data/course';
import { useAcademy } from '@/state/AcademyContext';
import { useColors } from '@/hooks/useColors';

export default function AcademyHome() {
  const colors = useColors();
  const router = useRouter();
  const { xp, completedModules, ready, bestExamScore, dailyRecords } = useAcademy();
  const nextModule = modules.find((module) => !completedModules.includes(module.id));
  const dailyCorrect = Object.values(dailyRecords).reduce(
    (total, answers) => total + Object.values(answers).filter((answer) => answer.correct).length,
    0,
  );
  const progress = Math.min(
    100,
    (completedModules.length / modules.length) * 80 +
      Math.min(10, dailyCorrect * 0.5) +
      (bestExamScore !== null && bestExamScore >= 80 ? 10 : 0),
  );
  const level = Math.floor(xp / 250) + 1;

  if (!ready) {
    return (
      <View style={[styles.loading, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} />
        <Text style={{ color: colors.mutedForeground, fontFamily: 'Inter_500Medium' }}>Carico i tuoi progressi…</Text>
      </View>
    );
  }

  return (
    <Page>
      <View style={styles.topLine}>
        <View>
          <Kicker>AI ACADEMY · PERCORSO</Kicker>
          <Text style={[styles.greeting, { color: colors.foreground }]}>Impara l’AI.{'\n'}Un passo alla volta.</Text>
        </View>
        <View style={[styles.xpPill, { backgroundColor: colors.accent, borderColor: colors.border }]}>
          <MaterialCommunityIcons name="lightning-bolt" size={17} color={colors.primary} />
          <Text style={[styles.xpText, { color: colors.foreground }]}>{xp} XP</Text>
        </View>
      </View>

      <Panel style={styles.progressPanel}>
        <View style={styles.progressTitleRow}>
          <View>
            <Text style={[styles.level, { color: colors.primary }]}>LIVELLO {level}</Text>
            <Text style={[styles.progressTitle, { color: colors.foreground }]}>Il tuo percorso</Text>
          </View>
          <View style={[styles.progressBadge, { backgroundColor: colors.muted }]}>
            <Text style={[styles.progressBadgeText, { color: colors.secondaryForeground }]}>{completedModules.length}/{modules.length}</Text>
          </View>
        </View>
        <ProgressBar value={progress} label="Corso completato" />
        <Text style={[styles.helper, { color: colors.mutedForeground }]}>
          {250 - (xp % 250)} XP al prossimo livello
        </Text>
      </Panel>

      {nextModule ? (
        <Panel style={[styles.featurePanel, { backgroundColor: colors.accent }]}>
          <View style={styles.featureTop}>
            <Chip active>IL PROSSIMO PASSO</Chip>
            <MaterialCommunityIcons name="arrow-top-right" size={21} color={colors.primary} />
          </View>
          <Text style={[styles.featureTitle, { color: colors.foreground }]}>{nextModule.title}</Text>
          <Text style={[styles.featureDescription, { color: colors.secondaryForeground }]}>{nextModule.subtitle}</Text>
          <ActionButton
            label={completedModules.length ? 'Riprendi il corso' : 'Inizia il corso'}
            onPress={() => router.push(`/lesson/${nextModule.id}` as any)}
            testID="continue-course"
          />
        </Panel>
      ) : (
        <Panel>
          <Kicker>TRAGUARDO RAGGIUNTO</Kicker>
          <Heading subtitle="Hai completato tutti gli 11 moduli del percorso.">Corso completato</Heading>
          <ActionButton label="Apri l’esame finale" onPress={() => router.push('/exam' as any)} />
        </Panel>
      )}

      <View style={styles.sectionHeader}>
        <View>
          <Kicker>IL PROGRAMMA</Kicker>
          <Heading subtitle="Undici capitoli, dalle origini alle applicazioni.">Il tuo percorso AI</Heading>
        </View>
      </View>

      {modules.map((module) => {
        const completed = completedModules.includes(module.id);
        return (
          <Pressable
            key={module.id}
            testID={`module-${module.id}`}
            accessibilityRole="button"
            onPress={() => router.push(`/lesson/${module.id}` as any)}
            style={({ pressed }) => [styles.moduleRow, { borderColor: colors.border, backgroundColor: colors.card, opacity: pressed ? 0.75 : 1 }]}
          >
            <View style={[styles.numberBadge, { backgroundColor: completed ? colors.primary : colors.muted }]}>
              {completed ? (
                <MaterialCommunityIcons name="check" size={17} color={colors.primaryForeground} />
              ) : (
                <Text style={[styles.moduleNumber, { color: colors.secondaryForeground }]}>{String(module.number).padStart(2, '0')}</Text>
              )}
            </View>
            <View style={styles.moduleInfo}>
              <Text style={[styles.moduleTitle, { color: colors.foreground }]} numberOfLines={1}>{module.title}</Text>
              <Text style={[styles.moduleSub, { color: colors.mutedForeground }]} numberOfLines={1}>{module.minutes} min · +50 XP</Text>
            </View>
            <MaterialCommunityIcons name="chevron-right" size={21} color={colors.mutedForeground} />
          </Pressable>
        );
      })}

      <Panel style={styles.examPanel}>
        <View style={[styles.examIcon, { backgroundColor: colors.accent }]}>
          <MaterialCommunityIcons name="certificate-outline" size={23} color={colors.primary} />
        </View>
        <Text style={[styles.featureTitle, { color: colors.foreground }]}>La prova finale</Text>
        <BodyText>30 domande su tutto il programma. Con l’80% ottieni il tuo certificato digitale.</BodyText>
        {bestExamScore !== null ? (
          <Text style={[styles.helper, { color: colors.primary }]}>Miglior risultato: {bestExamScore}%</Text>
        ) : null}
        <ActionButton label="Vai all’esame" variant="secondary" onPress={() => router.push('/exam' as any)} />
      </Panel>
      <View style={{ height: 8 }} />
    </Page>
  );
}

const styles = StyleSheet.create({
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  topLine: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 },
  greeting: { fontFamily: 'Inter_700Bold', fontSize: 31, lineHeight: 36, letterSpacing: -0.8, marginTop: 8 },
  xpPill: { flexDirection: 'row', alignItems: 'center', gap: 5, borderWidth: 1, borderRadius: 22, paddingHorizontal: 12, paddingVertical: 8 },
  xpText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  progressPanel: { gap: 13 },
  progressTitleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  level: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.4 },
  progressTitle: { fontFamily: 'Inter_700Bold', fontSize: 18, marginTop: 3 },
  progressBadge: { borderRadius: 12, paddingHorizontal: 10, paddingVertical: 7 },
  progressBadgeText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  helper: { fontFamily: 'Inter_500Medium', fontSize: 12, marginTop: 3 },
  featurePanel: { gap: 12 },
  featureTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  featureTitle: { fontFamily: 'Inter_700Bold', fontSize: 19, lineHeight: 25 },
  featureDescription: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 19, marginTop: -6, marginBottom: 3 },
  sectionHeader: { marginTop: 15 },
  moduleRow: { flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderRadius: 16, padding: 12, marginBottom: 8 },
  numberBadge: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  moduleNumber: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  moduleInfo: { flex: 1, gap: 4 },
  moduleTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  moduleSub: { fontFamily: 'Inter_400Regular', fontSize: 11 },
  examPanel: { marginTop: 18, gap: 10 },
  examIcon: { height: 39, width: 39, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
});
