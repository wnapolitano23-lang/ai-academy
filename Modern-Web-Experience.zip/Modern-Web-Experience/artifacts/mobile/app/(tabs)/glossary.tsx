import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { BodyText, Heading, Kicker, Page, Panel } from '@/components/AcademyUI';
import { glossary } from '@/data/course';
import { useColors } from '@/hooks/useColors';

export default function Glossary() {
  const colors = useColors();
  const [query, setQuery] = useState('');
  const [letter, setLetter] = useState('TUTTE');
  const [expandedTerm, setExpandedTerm] = useState<string | null>(null);
  const letters = ['TUTTE', ...Array.from(new Set(glossary.map((item) => item.letter))).sort()];
  const filtered = useMemo(() => glossary.filter((item) => {
    const matchesQuery = `${item.term} ${item.definition}`.toLocaleLowerCase('it').includes(query.trim().toLocaleLowerCase('it'));
    return matchesQuery && (letter === 'TUTTE' || item.letter === letter);
  }), [query, letter]);

  return (
    <Page>
      <Kicker>PAROLE CHIAVE</Kicker>
      <Heading subtitle="Concetti essenziali, spiegati in modo diretto.">Glossario AI</Heading>
      <View style={[styles.search, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <MaterialCommunityIcons name="magnify" size={20} color={colors.mutedForeground} />
        <TextInput
          testID="glossary-search"
          value={query}
          onChangeText={setQuery}
          placeholder="Cerca un termine"
          placeholderTextColor={colors.mutedForeground}
          accessibilityLabel="Cerca nel glossario"
          style={[styles.searchInput, { color: colors.foreground }]}
        />
        {query ? (
          <Pressable testID="clear-glossary-search" accessibilityRole="button" accessibilityLabel="Cancella ricerca" onPress={() => setQuery('')}>
            <MaterialCommunityIcons name="close-circle" size={19} color={colors.mutedForeground} />
          </Pressable>
        ) : null}
      </View>
      <FlatList
        horizontal
        data={letters}
        keyExtractor={(item) => item}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.letters}
        renderItem={({ item }) => (
          <Pressable
            accessibilityRole="button"
            testID={`glossary-letter-${item}`}
            onPress={() => setLetter(item)}
            style={[styles.letterButton, { backgroundColor: letter === item ? colors.primary : colors.card, borderColor: letter === item ? colors.primary : colors.border }]}
          >
            <Text style={[styles.letterText, { color: letter === item ? colors.primaryForeground : colors.mutedForeground }]}>{item}</Text>
          </Pressable>
        )}
      />
      <Text style={[styles.results, { color: colors.mutedForeground }]}>{filtered.length} {filtered.length === 1 ? 'TERMINE' : 'TERMINI'}</Text>
      {filtered.length ? filtered.map((item) => {
        const expanded = expandedTerm === item.term;
        return (
          <Pressable
            key={item.term}
            testID={`glossary-term-${item.term.replaceAll(' ', '-')}`}
            accessibilityRole="button"
            onPress={() => setExpandedTerm(expanded ? null : item.term)}
          >
            <Panel style={styles.termPanel}>
              <View style={styles.termHead}>
                <View style={[styles.letterBadge, { backgroundColor: colors.accent }]}>
                  <Text style={[styles.letterBadgeText, { color: colors.primary }]}>{item.letter}</Text>
                </View>
                <Text style={[styles.term, { color: colors.foreground }]}>{item.term}</Text>
                <MaterialCommunityIcons name={expanded ? 'chevron-up' : 'chevron-down'} size={19} color={colors.mutedForeground} />
              </View>
              {expanded ? <BodyText>{item.definition}</BodyText> : null}
            </Panel>
          </Pressable>
        );
      }) : (
        <Panel style={styles.empty}>
          <MaterialCommunityIcons name="book-search-outline" size={25} color={colors.mutedForeground} />
          <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Nessun termine trovato. Prova un’altra parola.</Text>
        </Panel>
      )}
      <View style={{ height: 12 }} />
    </Page>
  );
}

const styles = StyleSheet.create({
  search: { height: 50, borderWidth: 1, borderRadius: 15, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 9, marginBottom: 12 },
  searchInput: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 14, height: '100%' },
  letters: { gap: 7, paddingVertical: 3, paddingBottom: 13 },
  letterButton: { paddingHorizontal: 11, paddingVertical: 8, borderRadius: 20, borderWidth: 1 },
  letterText: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 0.3 },
  results: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.2, marginVertical: 7 },
  termPanel: { marginBottom: 8, padding: 13, gap: 10 },
  termHead: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  letterBadge: { width: 29, height: 29, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  letterBadgeText: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  term: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  empty: { alignItems: 'center', gap: 10, paddingVertical: 25 },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 13, textAlign: 'center' },
});
