import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { ActionButton, BodyText, Chip, Heading, Kicker, Page, Panel, ProgressBar } from '@/components/AcademyUI';
import { finalQuestions, modules } from '@/data/course';
import { useAcademy } from '@/state/AcademyContext';
import { useColors } from '@/hooks/useColors';

export default function FinalExam() {
  const colors = useColors();
  const router = useRouter();
  const { certificateName, setCertificateName, submitExam, examAttempts, completedModules, bestExamScore } = useAcademy();
  const [name, setName] = useState(certificateName);
  const [started, setStarted] = useState(false);
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [result, setResult] = useState<number | null>(null);
  const question = finalQuestions[index];
  const currentAnswer = answers[question?.id];
  const isLast = index === finalQuestions.length - 1;

  function finish() {
    const correct = finalQuestions.reduce(
      (count, item) => count + (answers[item.id] === item.answer ? 1 : 0),
      0,
    );
    const score = Math.round((correct / finalQuestions.length) * 100);
    setResult(score);
    setCertificateName(name);
    submitExam(score, name);
    Haptics.notificationAsync(score >= 80 ? Haptics.NotificationFeedbackType.Success : Haptics.NotificationFeedbackType.Warning).catch(() => undefined);
    if (score >= 80) router.replace('/certificate' as any);
  }

  function retry() {
    setAnswers({});
    setIndex(0);
    setResult(null);
    setStarted(true);
  }

  return (
    <Page>
      <Pressable accessibilityRole="button" testID="exam-back" onPress={() => router.back()} style={styles.back}>
        <MaterialCommunityIcons name="arrow-left" size={20} color={colors.primary} />
        <Text style={[styles.backText, { color: colors.primary }]}>TORNA INDIETRO</Text>
      </Pressable>
      <Kicker>PROVA DI APPRENDIMENTO</Kicker>
      <Heading subtitle="30 domande sui concetti chiave di tutti gli 11 moduli.">Esame finale</Heading>

      {!started && result === null ? (
        <Panel style={styles.introPanel}>
          <View style={[styles.examIcon, { backgroundColor: colors.accent }]}>
            <MaterialCommunityIcons name="certificate-outline" size={25} color={colors.primary} />
          </View>
          <Text style={[styles.panelTitle, { color: colors.foreground }]}>Un ultimo passo</Text>
          <BodyText>Rispondi a 30 domande. Per sbloccare il certificato serve almeno l’80%. Il tuo risultato migliore viene salvato.</BodyText>
          <View style={[styles.infoRow, { borderColor: colors.border }]}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>MODULI COMPLETATI</Text>
            <Text style={[styles.infoValue, { color: colors.foreground }]}>{completedModules.length} / {modules.length}</Text>
          </View>
          <View style={[styles.infoRow, { borderColor: colors.border }]}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>SOGLIA CERTIFICATO</Text>
            <Text style={[styles.infoValue, { color: colors.primary }]}>80%</Text>
          </View>
          {bestExamScore !== null ? <Text style={[styles.helper, { color: colors.mutedForeground }]}>Miglior risultato: {bestExamScore}% · tentativi: {examAttempts}</Text> : null}
          <Text style={[styles.label, { color: colors.secondaryForeground }]}>NOME SUL CERTIFICATO</Text>
          <TextInput
            testID="certificate-name"
            value={name}
            onChangeText={(value) => {
              setName(value);
              setCertificateName(value);
            }}
            placeholder="Il tuo nome"
            placeholderTextColor={colors.mutedForeground}
            autoCapitalize="words"
            style={[styles.nameInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]}
          />
          <ActionButton label="Inizia l’esame" disabled={!name.trim()} onPress={() => { setStarted(true); setIndex(0); setAnswers({}); }} testID="start-exam" />
          {!name.trim() ? <Text style={[styles.helper, { color: colors.mutedForeground }]}>Inserisci il nome da mostrare sul certificato.</Text> : null}
        </Panel>
      ) : null}

      {started && result === null && question ? (
        <>
          <Panel style={styles.questionPanel}>
            <View style={styles.questionTop}>
              <Chip>DOMANDA {index + 1} / {finalQuestions.length}</Chip>
              <Text style={[styles.points, { color: colors.mutedForeground }]}>30 domande</Text>
            </View>
            <ProgressBar value={((index + 1) / finalQuestions.length) * 100} />
            <Text style={[styles.questionText, { color: colors.foreground }]}>{question.prompt}</Text>
            <View style={{ gap: 9, marginTop: 7 }}>
              {question.options.map((option, optionIndex) => {
                const selected = currentAnswer === optionIndex;
                return (
                  <Pressable
                    key={option}
                    testID={`exam-answer-${index}-${optionIndex}`}
                    accessibilityRole="button"
                    onPress={() => setAnswers((current) => ({ ...current, [question.id]: optionIndex }))}
                    style={({ pressed }) => [
                      styles.answerOption,
                      {
                        borderColor: selected ? colors.primary : colors.border,
                        backgroundColor: selected ? colors.accent : colors.background,
                        opacity: pressed ? 0.75 : 1,
                      },
                    ]}
                  >
                    <View style={[styles.answerLetter, { backgroundColor: selected ? colors.primary : colors.muted }]}>
                      <Text style={[styles.answerLetterText, { color: selected ? colors.primaryForeground : colors.mutedForeground }]}>{String.fromCharCode(65 + optionIndex)}</Text>
                    </View>
                    <Text style={[styles.answerText, { color: colors.foreground }]}>{option}</Text>
                  </Pressable>
                );
              })}
            </View>
          </Panel>
          <View style={styles.navigation}>
            <ActionButton label="Precedente" variant="secondary" disabled={index === 0} onPress={() => setIndex((value) => value - 1)} />
            {isLast ? (
              <ActionButton label="Concludi e calcola" disabled={Object.keys(answers).length < finalQuestions.length} onPress={finish} />
            ) : (
              <ActionButton label="Continua" disabled={currentAnswer === undefined} onPress={() => setIndex((value) => value + 1)} />
            )}
          </View>
          <Text style={[styles.helper, { color: colors.mutedForeground }]}>Le risposte restano modificabili finché non concludi.</Text>
        </>
      ) : null}

      {result !== null && result < 80 ? (
        <Panel style={styles.resultPanel}>
          <View style={[styles.resultIcon, { backgroundColor: colors.muted }]}>
            <MaterialCommunityIcons name="refresh" size={23} color={colors.primary} />
          </View>
          <Heading subtitle={`Hai ottenuto ${result}%. La soglia per il certificato è 80%.`}>Un altro tentativo?</Heading>
          <BodyText>Rivedi i moduli e riprova quando vuoi. Il tuo miglior punteggio resta salvato.</BodyText>
          <ActionButton label="Riprova l’esame" onPress={retry} />
          <ActionButton label="Torna al percorso" variant="secondary" onPress={() => router.replace('/' as any)} />
        </Panel>
      ) : null}
    </Page>
  );
}

const styles = StyleSheet.create({
  back: { flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 18 },
  backText: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.2 },
  introPanel: { gap: 14 },
  examIcon: { width: 51, height: 51, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  panelTitle: { fontFamily: 'Inter_700Bold', fontSize: 19 },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderBottomWidth: StyleSheet.hairlineWidth, paddingVertical: 10 },
  infoLabel: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 0.7 },
  infoValue: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  helper: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17 },
  label: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1, marginBottom: -7 },
  nameInput: { height: 48, borderWidth: 1, borderRadius: 13, paddingHorizontal: 12, fontFamily: 'Inter_500Medium', fontSize: 14 },
  questionPanel: { gap: 15 },
  questionTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  points: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  questionText: { fontFamily: 'Inter_700Bold', fontSize: 18, lineHeight: 26 },
  answerOption: { minHeight: 52, borderRadius: 14, borderWidth: 1, padding: 10, flexDirection: 'row', gap: 10, alignItems: 'center' },
  answerLetter: { width: 29, height: 29, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  answerLetterText: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  answerText: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 13, lineHeight: 19 },
  navigation: { flexDirection: 'row', gap: 9 },
  resultPanel: { gap: 12, marginTop: 7 },
  resultIcon: { width: 47, height: 47, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
});
