import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { ActionButton, BodyText, Chip, Kicker, Page, Panel, ProgressBar } from '@/components/AcademyUI';
import { modules } from '@/data/course';
import { useAcademy } from '@/state/AcademyContext';
import { useColors } from '@/hooks/useColors';

export default function LessonPage() {
  const colors = useColors();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { completedModules, completeModule, ready } = useAcademy();
  const module = modules.find((item) => item.id === id);
  const completed = module ? completedModules.includes(module.id) : false;
  const words = module?.sections.reduce((sum, section) => sum + section.body.trim().split(/\s+/).length, 0) ?? 0;

  if (!ready) {
    return <View style={[styles.loading, { backgroundColor: colors.background }]}><ActivityIndicator color={colors.primary} /></View>;
  }
  if (!module) {
    return (
      <Page>
        <Kicker>LEZIONE NON TROVATA</Kicker>
        <ActionButton label="Torna al percorso" onPress={() => router.replace('/' as any)} />
      </Page>
    );
  }

  return (
    <Page>
      <Pressable accessibilityRole="button" testID="lesson-back" onPress={() => router.back()} style={styles.back}>
        <MaterialCommunityIcons name="arrow-left" size={20} color={colors.primary} />
        <Text style={[styles.backText, { color: colors.primary }]}>IL TUO PERCORSO</Text>
      </Pressable>
      <View style={styles.lessonMeta}>
        <Chip>MODULO {String(module.number).padStart(2, '0')}</Chip>
        <Text style={[styles.readTime, { color: colors.mutedForeground }]}>{module.minutes} MIN · {words} PAROLE</Text>
      </View>
      <Text style={[styles.title, { color: colors.foreground }]}>{module.title}</Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{module.subtitle}</Text>
      <View style={styles.lessonProgress}>
        <ProgressBar value={(module.number / modules.length) * 100} label="Posizione nel corso" />
      </View>

      {module.sections.map((section, index) => (
        <Panel key={section.title} style={styles.sectionPanel}>
          <View style={styles.sectionHeading}>
            <View style={[styles.sectionNumber, { backgroundColor: colors.accent }]}>
              <Text style={[styles.sectionNumberText, { color: colors.primary }]}>{String(index + 1).padStart(2, '0')}</Text>
            </View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{section.title}</Text>
          </View>
          <BodyText style={styles.lessonBody}>{section.body}</BodyText>
        </Panel>
      ))}

      <Panel style={[styles.keyPanel, { backgroundColor: colors.accent }]}>
        <View style={styles.calloutHead}>
          <MaterialCommunityIcons name="lightbulb-on-outline" size={19} color={colors.primary} />
          <Text style={[styles.calloutTitle, { color: colors.primary }]}>DA RICORDARE</Text>
        </View>
        <BodyText>{module.keyIdea}</BodyText>
      </Panel>
      <Panel style={styles.mistakePanel}>
        <View style={styles.calloutHead}>
          <MaterialCommunityIcons name="alert-circle-outline" size={19} color={colors.destructive} />
          <Text style={[styles.calloutTitle, { color: colors.destructive }]}>ERRORE COMUNE</Text>
        </View>
        <BodyText>{module.commonMistake}</BodyText>
      </Panel>
      <ActionButton
        testID={`complete-${module.id}`}
        label={completed ? 'Completato · +50 XP assegnati' : 'Segna come Completato (+50 XP)'}
        disabled={completed}
        onPress={() => {
          completeModule(module.id);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => undefined);
        }}
      />
      {completed ? <Text style={[styles.completedHint, { color: colors.mutedForeground }]}>La lezione resta disponibile nel tuo percorso.</Text> : null}
      <View style={{ height: 20 }} />
    </Page>
  );
}

const styles = StyleSheet.create({
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  back: { flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 18 },
  backText: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.2 },
  lessonMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8, marginBottom: 11 },
  readTime: { fontFamily: 'Inter_600SemiBold', fontSize: 9, letterSpacing: 0.6 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, lineHeight: 36, letterSpacing: -0.8 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 15, lineHeight: 22, marginTop: 8 },
  lessonProgress: { marginTop: 21, marginBottom: 17 },
  sectionPanel: { gap: 13, padding: 16 },
  sectionHeading: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  sectionNumber: { width: 33, height: 33, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  sectionNumberText: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  sectionTitle: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 16, lineHeight: 21 },
  lessonBody: { fontSize: 14, lineHeight: 24 },
  keyPanel: { gap: 11 },
  mistakePanel: { gap: 11 },
  calloutHead: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  calloutTitle: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.2 },
  completedHint: { fontFamily: 'Inter_400Regular', fontSize: 11, textAlign: 'center', marginTop: 10 },
});
