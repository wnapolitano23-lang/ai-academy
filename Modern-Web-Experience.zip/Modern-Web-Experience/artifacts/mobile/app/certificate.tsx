import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { ActionButton, BodyText, Kicker, Page, Panel } from '@/components/AcademyUI';
import { useAcademy } from '@/state/AcademyContext';
import { useColors } from '@/hooks/useColors';

export default function CertificatePage() {
  const colors = useColors();
  const router = useRouter();
  const { bestExamScore, certificateName, setCertificateName, examAttempts } = useAcademy();
  const [name, setName] = useState(certificateName);
  const passed = bestExamScore !== null && bestExamScore >= 80;

  return (
    <Page>
      <Pressable accessibilityRole="button" testID="certificate-back" onPress={() => router.back()} style={styles.back}>
        <MaterialCommunityIcons name="arrow-left" size={20} color={colors.primary} />
        <Text style={[styles.backText, { color: colors.primary }]}>TORNA INDIETRO</Text>
      </Pressable>
      {passed ? (
        <>
          <Kicker>TRAGUARDO CERTIFICATO</Kicker>
          <Text style={[styles.pageTitle, { color: colors.foreground }]}>Il tuo certificato</Text>
          <Panel style={[styles.certificate, { borderColor: colors.primary }]}>
            <View style={styles.certificateTop}>
              <View style={[styles.seal, { backgroundColor: colors.accent }]}>
                <MaterialCommunityIcons name="school-outline" size={26} color={colors.primary} />
              </View>
              <Text style={[styles.brand, { color: colors.primary }]}>AI ACADEMY</Text>
              <View style={[styles.rule, { backgroundColor: colors.primary }]} />
            </View>
            <Text style={[styles.overline, { color: colors.mutedForeground }]}>CERTIFICATO DI COMPLETAMENTO</Text>
            <Text style={[styles.certify, { color: colors.secondaryForeground }]}>Si attesta che</Text>
            <Text style={[styles.recipient, { color: colors.foreground }]}>{certificateName || 'Studentessa / Studente'}</Text>
            <Text style={[styles.certify, { color: colors.secondaryForeground }]}>ha completato il corso approfondito</Text>
            <Text style={[styles.courseName, { color: colors.foreground }]}>Intelligenza Artificiale</Text>
            <Text style={[styles.certify, { color: colors.mutedForeground }]}>con un risultato finale di</Text>
            <Text style={[styles.result, { color: colors.primary }]}>{bestExamScore}%</Text>
            <View style={[styles.rule, { backgroundColor: colors.border }]} />
            <Text style={[styles.credential, { color: colors.mutedForeground }]}>ESAME SUPERATO · SOGLIA 80% · {examAttempts} {examAttempts === 1 ? 'TENTATIVO' : 'TENTATIVI'}</Text>
          </Panel>
          <Text style={[styles.nameLabel, { color: colors.secondaryForeground }]}>Personalizza il nome visualizzato</Text>
          <TextInput
            testID="edit-certificate-name"
            value={name}
            onChangeText={(value) => {
              setName(value);
              setCertificateName(value);
            }}
            placeholder="Il tuo nome"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.nameInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.card }]}
          />
          <BodyText>Il certificato è salvato in questo dispositivo. Nome e progressi possono essere aggiornati in qualsiasi momento.</BodyText>
          <ActionButton label="Torna al percorso" variant="secondary" onPress={() => router.replace('/' as any)} />
        </>
      ) : (
        <Panel style={styles.locked}>
          <View style={[styles.seal, { backgroundColor: colors.muted }]}>
            <MaterialCommunityIcons name="lock-outline" size={25} color={colors.mutedForeground} />
          </View>
          <Kicker>ANCORA DA SBLOCCARE</Kicker>
          <Text style={[styles.pageTitle, { color: colors.foreground }]}>Un traguardo alla volta</Text>
          <BodyText>Supera l’esame finale con almeno l’80% per ottenere il certificato personalizzato.</BodyText>
          <ActionButton label="Vai all’esame" onPress={() => router.replace('/exam' as any)} />
        </Panel>
      )}
      <View style={{ height: 20 }} />
    </Page>
  );
}

const styles = StyleSheet.create({
  back: { flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 18 },
  backText: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.2 },
  pageTitle: { fontFamily: 'Inter_700Bold', fontSize: 28, lineHeight: 34, marginTop: 8, marginBottom: 18 },
  certificate: { alignItems: 'center', paddingVertical: 24, gap: 11 },
  certificateTop: { alignItems: 'center', gap: 9, width: '100%', marginBottom: 6 },
  seal: { width: 57, height: 57, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  brand: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 2.1 },
  rule: { height: 1, width: '82%', marginVertical: 8 },
  overline: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.5, textAlign: 'center' },
  certify: { fontFamily: 'Inter_400Regular', fontSize: 13, textAlign: 'center' },
  recipient: { fontFamily: 'Inter_700Bold', fontSize: 24, textAlign: 'center', marginVertical: 3 },
  courseName: { fontFamily: 'Inter_700Bold', fontSize: 18, textAlign: 'center' },
  result: { fontFamily: 'Inter_700Bold', fontSize: 30 },
  credential: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.7, textAlign: 'center', lineHeight: 15 },
  nameLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 12, marginTop: 11, marginBottom: 7 },
  nameInput: { height: 48, borderWidth: 1, borderRadius: 13, paddingHorizontal: 12, fontFamily: 'Inter_500Medium', fontSize: 14, marginBottom: 12 },
  locked: { alignItems: 'flex-start', gap: 12, paddingVertical: 24 },
});
