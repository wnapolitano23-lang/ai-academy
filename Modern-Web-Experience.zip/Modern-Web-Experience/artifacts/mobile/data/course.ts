export type LessonSection = { title: string; body: string };
export type CourseModule = {
  id: string;
  number: number;
  title: string;
  subtitle: string;
  minutes: number;
  sections: LessonSection[];
  keyIdea: string;
  commonMistake: string;
};

export const modules: CourseModule[] = [
  {
    id: 'storia',
    number: 1,
    title: 'Storia dell’intelligenza artificiale',
    subtitle: 'Dalla macchina di Turing all’era dei Transformer',
    minutes: 12,
    sections: [
      {
        title: 'Una domanda prima di una tecnologia',
        body: `La storia dell’intelligenza artificiale comincia con una domanda teorica: che cosa significa dire che una macchina pensa? Nel 1936 Alan Turing descrisse una macchina astratta capace di manipolare simboli seguendo istruzioni finite. Non era un progetto di computer intelligente, ma un modello matematico della computazione: mostrava che procedure diverse potevano essere rappresentate da un insieme universale di operazioni. Dopo la guerra, i primi calcolatori elettronici resero questa idea tangibile. Nel 1950 Turing propose il “gioco dell’imitazione”, oggi noto come test di Turing: un modo operativo, anche se discusso, per chiedersi se una conversazione scritta permetta di distinguere un interlocutore umano da una macchina. La domanda spostava l’attenzione dall’essenza della mente al comportamento osservabile, un passaggio che ancora influenza il dibattito pubblico sull’AI.`,
      },
      {
        title: 'Dartmouth e l’AI simbolica',
        body: `Nel 1956 il seminario di Dartmouth consolidò il nome “intelligenza artificiale” e l’aspettativa che aspetti dell’apprendimento e del ragionamento potessero essere descritti con precisione sufficiente da farli eseguire a una macchina. I primi programmi manipolavano simboli: rappresentavano fatti, regole e relazioni, poi cercavano una dimostrazione o una sequenza di mosse. Un sistema poteva, per esempio, ricevere le premesse “tutti gli esseri umani sono mortali” e “Socrate è umano” e derivare una conclusione applicando regole logiche. Questo approccio funzionava bene in domini ristretti e puliti, come dimostrazioni matematiche o giochi con regole esplicite. Era però costoso descrivere il mondo reale con eccezioni e conoscenza tacita. La differenza fra “sapere le regole” e “saper riconoscere una situazione” emerse presto: un programma esperto in un ambiente controllato non sapeva necessariamente adattarsi a una domanda formulata in modo nuovo.`,
      },
      {
        title: 'Reti, perceptron e inverni dell’AI',
        body: `In parallelo si sviluppò una linea ispirata alle reti biologiche. Il perceptron di Frank Rosenblatt, presentato nel 1958, combinava ingressi numerici con pesi e produceva una classificazione. La sua regola di apprendimento modificava i pesi in base agli errori, un’idea che anticipa il training moderno. Le prime versioni, tuttavia, risolvevano solo problemi separabili da una frontiera lineare e avevano limiti dimostrabili. Le aspettative pubbliche superarono spesso ciò che dati, hardware e algoritmi potevano sostenere. Quando i risultati non mantennero le promesse e i finanziamenti diminuirono, si verificarono periodi chiamati “inverni dell’AI”. Il nome non indica che la ricerca si fermò: ricercatori continuarono a sviluppare logica, pianificazione e reti neurali, ma con meno clamore e risorse. Questa alternanza fra entusiasmo e revisione delle aspettative è un tema ricorrente e aiuta a valutare con prudenza ogni nuova ondata tecnologica.`,
      },
      {
        title: 'Dai sistemi esperti al deep learning',
        body: `Negli anni Settanta e Ottanta i sistemi esperti codificarono competenze in regole del tipo “se… allora…”. In ambiti delimitati, come la diagnosi di guasti industriali, offrivano risultati utili e spiegabili. La manutenzione della base di regole diventava però difficile: nuove eccezioni richiedevano interventi manuali e una regola poteva entrare in conflitto con un’altra. La crescita dei dati digitali, la potenza dei processori grafici e progressi negli algoritmi di ottimizzazione favorirono un cambio di prospettiva. Invece di elencare ogni regola, si addestrava un modello su esempi e si misurava quanto bene generalizzasse a casi non visti. Le reti profonde tornarono così centrali: più strati potevano apprendere rappresentazioni progressive, dai bordi di un’immagine a forme più complesse. Il successo di sistemi come AlexNet nella competizione ImageNet del 2012 rese evidente il valore pratico di questa combinazione di dati, calcolo e architetture profonde.`,
      },
      {
        title: 'La svolta dei Transformer e dei modelli linguistici',
        body: `Nel 2017 il lavoro “Attention Is All You Need” introdusse l’architettura Transformer, che usa meccanismi di attenzione per mettere in relazione elementi di una sequenza. A differenza delle reti ricorrenti, il Transformer può elaborare molte posizioni in parallelo durante l’addestramento e apprendere quali parole o token siano rilevanti l’uno per l’altro. Addestrati su grandi collezioni di testo, i modelli linguistici imparano a stimare il token successivo e acquisiscono regolarità grammaticali, conoscenze ricorrenti e schemi di ragionamento presenti nei dati. Modelli come GPT, Gemini e Claude appartengono a famiglie e strategie diverse: i nomi commerciali non implicano un’unica architettura identica. La chat moderna nasce anche da fasi successive di allineamento, valutazione e progettazione dell’interfaccia. Un sistema convincente non è quindi il risultato di un singolo algoritmo, ma di una catena di scelte tecniche e organizzative.`,
      },
      {
        title: 'Come leggere la storia senza cadere nei miti',
        body: `Ogni epoca ha ridefinito “intelligenza” in base ai problemi che sapeva formalizzare. Un programma che gioca a scacchi può superare molte persone senza possedere comprensione generale; un modello che scrive bene può produrre frasi plausibili senza verificare che ogni fatto sia corretto. Per interpretare un risultato storico conviene chiedere quale compito veniva svolto, con quali dati, metriche e ipotesi, e in quali condizioni il sistema falliva. Anche le date vanno lette come tappe di una storia cumulativa: il deep learning non ha cancellato la logica, e i Transformer non hanno risolto automaticamente i problemi di affidabilità, causalità o apprendimento efficiente. Questa prospettiva evita sia la narrazione secondo cui l’AI sarebbe nata ieri, sia l’idea che ogni progresso annunci una macchina onnisciente. La storia è utile perché mostra che capacità, limiti e aspettative cambiano insieme.`,
      },
    ],
    keyIdea: 'L’AI è una disciplina con più tradizioni: simbolica, statistica e connessionista.',
    commonMistake: 'Confondere un risultato impressionante in un compito specifico con un’intelligenza generale.',
  },
  {
    id: 'machine-learning',
    number: 2,
    title: 'Basi di Machine Learning',
    subtitle: 'Imparare dai dati, non da un elenco di regole',
    minutes: 14,
    sections: [
      {
        title: 'Che cosa impara un modello',
        body: `Il machine learning è un insieme di metodi con cui un programma ricava regolarità dai dati per svolgere un compito. Invece di scrivere una regola per ogni possibile situazione, si scelgono esempi, una rappresentazione del problema e una funzione obiettivo. Un modello contiene parametri, cioè valori numerici che vengono regolati durante l’addestramento. Per una previsione del prezzo di una casa, gli ingressi potrebbero essere superficie, zona e anno di costruzione; l’uscita è un valore stimato. La qualità non dipende soltanto dall’algoritmo: contano la definizione del problema, la qualità e la rappresentatività dei dati, la metrica scelta e l’uso previsto. Se una squadra ottimizza una misura che non riflette il bisogno reale, il sistema può migliorare il punteggio senza migliorare la decisione. Prima di “addestrare l’AI” è quindi necessario esplicitare che cosa si vuole prevedere e quale errore sia più costoso.`,
      },
      {
        title: 'Apprendimento supervisionato',
        body: `Nel supervised learning ogni esempio di training comprende input e risposta attesa, detta etichetta. In una classificazione l’etichetta è una categoria, come “transazione sospetta” o “non sospetta”; in una regressione è un numero, come la domanda prevista per il mese successivo. Il modello produce una stima e una funzione di perdita quantifica quanto questa differisca dalla risposta. L’ottimizzatore modifica i parametri per ridurre mediamente la perdita sui dati di addestramento. I dati si dividono normalmente in training, validation e test: il primo gruppo serve a imparare, il secondo a confrontare scelte e regolare impostazioni, il terzo resta separato per una valutazione finale più onesta. Se il test viene consultato ripetutamente durante lo sviluppo, smette di essere davvero indipendente. Inoltre, etichette incoerenti o influenzate da decisioni storiche possono insegnare al modello la stessa incoerenza.`,
      },
      {
        title: 'Apprendimento non supervisionato',
        body: `Nell’apprendimento non supervisionato gli esempi non hanno una risposta assegnata per il compito. Algoritmi di clustering raggruppano punti simili secondo una misura e una rappresentazione scelte; metodi di riduzione della dimensionalità cercano una descrizione più compatta dei dati. Questi strumenti sono utili per esplorare segmenti di clientela, individuare strutture in misure scientifiche o comprimere rappresentazioni. Un gruppo trovato matematicamente non è automaticamente una categoria naturale o significativa: cambiare scala, variabili o metrica può cambiare i gruppi. L’analista deve interpretare i risultati alla luce del dominio, confrontare più configurazioni e verificare che le differenze siano utili e non soltanto visibili. La parola “non supervisionato” non significa assenza di scelte umane: selezione delle caratteristiche, definizione della distanza, numero di gruppi e criteri di valutazione incidono sul risultato.`,
      },
      {
        title: 'Apprendimento per rinforzo',
        body: `Nel reinforcement learning un agente interagisce con un ambiente, osserva uno stato, sceglie un’azione e riceve una ricompensa. L’obiettivo è apprendere una politica che massimizzi la ricompensa cumulativa nel tempo, non soltanto quella immediata. Un robot potrebbe imparare a muoversi ricevendo segnali per raggiungere una destinazione e penalità per urti; un sistema di simulazione può provare molte traiettorie senza mettere persone a rischio. Un problema classico è il compromesso fra esplorazione, cioè provare azioni poco conosciute, e sfruttamento, cioè scegliere quelle che finora hanno funzionato. La ricompensa è una formalizzazione incompleta dell’obiettivo umano: se è progettata male, l’agente può trovare strategie inattese che massimizzano il punteggio ma tradiscono lo scopo. Esperimenti controllati, limiti di sicurezza e supervisione sono quindi importanti, specialmente quando le azioni hanno conseguenze reali.`,
      },
      {
        title: 'Generalizzazione, sovra-adattamento e metriche',
        body: `Un modello è utile quando funziona anche su esempi futuri, non solo su quelli già visti. L’overfitting si verifica quando il sistema si adatta troppo ai dettagli del training, compresi rumore e coincidenze, e perde precisione su dati nuovi. Il rischio aumenta con pochi esempi, troppe variabili o valutazioni ripetute sullo stesso set. La validazione separata, la regolarizzazione e la raccolta di dati rappresentativi aiutano, ma non sostituiscono una valutazione nel contesto d’uso. L’accuracy può essere fuorviante in classi sbilanciate: se il 99% delle transazioni è normale, un classificatore che risponde sempre “normale” appare accurato ma non trova frodi. Precisione e richiamo descrivono compromessi diversi fra falsi allarmi e casi mancati; la calibrazione verifica se una probabilità stimata corrisponde a frequenze osservate. La metrica va scelta insieme a chi subirà gli errori, non soltanto per comodità tecnica.`,
      },
      {
        title: 'Un processo di lavoro affidabile',
        body: `Un progetto tipico parte da una domanda misurabile e da una decisione che il modello dovrebbe supportare. Il team controlla poi provenienza, permessi, qualità e copertura dei dati, stabilisce una baseline semplice e confronta i modelli con criteri concordati. Dopo il test iniziale, servono prove su gruppi differenti, condizioni rare e casi ambigui. La messa in produzione richiede monitoraggio: nel tempo cambiano i comportamenti delle persone, i processi aziendali e la distribuzione degli ingressi. Un sistema che era accurato al lancio può degradare o creare effetti inattesi. Per questo si conservano versioni, si documentano le modifiche e si definisce chi può sospendere o correggere il servizio. Il machine learning non elimina la responsabilità: la rende più distribuita fra chi raccoglie dati, chi costruisce il modello e chi decide come usarlo.`,
      },
      {
        title: 'Una checklist prima di fidarsi',
        body: `Prima di adottare una previsione, annota quale decisione cambierà, quali dati saranno disponibili al momento della decisione e quale errore è più dannoso. Verifica che la separazione tra training e test rispetti il tempo: nei dati di vendita, per esempio, una riga futura non dovrebbe aiutare a prevedere il passato. Controlla le classi rare e confronta metriche per sottogruppi, se è lecito e pertinente. Poi confronta il modello con una baseline semplice, come la regola attuale o una media storica. Se il vantaggio scompare fuori campione, la soluzione non è pronta. Queste verifiche trasformano un punteggio astratto in una decisione informata e documentabile.`,
      },
    ],
    keyIdea: 'I dati, la metrica e la valutazione sono parte del modello tanto quanto l’algoritmo.',
    commonMistake: 'Valutare il successo solo sul training o affidarsi all’accuracy senza guardare gli errori.',
  },
  {
    id: 'reti-neurali',
    number: 3,
    title: 'Reti neurali e Deep Learning',
    subtitle: 'Pesi, funzioni di attivazione e apprendimento',
    minutes: 15,
    sections: [
      {
        title: 'Dal neurone biologico al modello matematico',
        body: `Le reti neurali artificiali prendono ispirazione, in modo molto semplificato, dalle reti di neuroni biologici. Un neurone artificiale riceve valori numerici, moltiplica ciascun ingresso per un peso, somma i risultati con un termine di bias e applica una funzione di attivazione. Si può scrivere la trasformazione come z = w·x + b e l’uscita come a = f(z). I pesi controllano l’influenza dei segnali; il bias sposta la soglia o il valore di riferimento. Questa analogia non implica che una rete artificiale riproduca il cervello: i neuroni biologici sono molto più complessi, dinamici e incarnati in un organismo. La metafora è comunque utile per capire perché molte unità semplici, organizzate in una rete e addestrate su esempi, possano apprendere trasformazioni non lineari.`,
      },
      {
        title: 'Strati e funzioni di attivazione',
        body: `Uno strato raggruppa unità che trasformano simultaneamente le rappresentazioni ricevute. Lo strato di input codifica le caratteristiche iniziali; gli strati intermedi costruiscono rappresentazioni successive; lo strato finale produce una stima o una distribuzione di classi. Se tutte le trasformazioni fossero lineari, impilare molti strati equivale a una sola trasformazione lineare e non aggiungerebbe potere espressivo. Funzioni come ReLU, sigmoide e tanh introducono non linearità, con comportamenti e limiti diversi. ReLU conserva valori positivi e azzera quelli negativi, ed è semplice da ottimizzare in molti contesti. La sigmoide produce valori fra zero e uno ed è adatta a certe probabilità binarie, ma può saturare. La softmax trasforma una serie di punteggi in valori che sommano a uno, utile per classificazioni mutuamente esclusive. La scelta dell’uscita dipende dal problema, non da un’estetica dell’architettura.`,
      },
      {
        title: 'La funzione di perdita come segnale',
        body: `Per addestrare la rete bisogna misurare la distanza fra l’uscita prodotta e il risultato desiderato. Questa misura è la funzione di perdita. Un problema di regressione può usare l’errore quadratico medio; una classificazione usa spesso la cross-entropy fra probabilità previste e classe attesa. Il processo parte da pesi iniziali, fa passare un esempio in avanti attraverso gli strati e calcola la previsione. Confronta poi la previsione con l’etichetta e ottiene un errore numerico. L’obiettivo non è “capire” quell’errore come farebbe una persona: è trovare una direzione matematica che cambi i parametri per renderlo meno probabile sui dati. Una scelta sbagliata della perdita può dare incentivi sbagliati, per esempio facendo apparire accettabile un errore raro ma molto dannoso. Anche il bilanciamento fra esempi e classi influenza il segnale ricevuto dal modello.`,
      },
      {
        title: 'Backpropagation e discesa del gradiente',
        body: `La backpropagation applica la regola della catena per calcolare come cambia la perdita al variare di ogni peso e bias. Partendo dall’errore finale, propaga all’indietro gradienti attraverso ciascuna operazione della rete. La discesa del gradiente aggiorna i parametri in direzione opposta al gradiente, perché questa direzione tende a ridurre localmente la perdita. Il learning rate regola la grandezza degli aggiornamenti: se è troppo alto, l’ottimizzazione può oscillare o divergere; se è troppo basso, può avanzare con lentezza. In pratica gli aggiornamenti usano mini-batch di esempi e spesso varianti come Adam, che adattano i passi in base alle statistiche dei gradienti. L’algoritmo non garantisce il minimo globale per ogni architettura, ma nella pratica trova spesso soluzioni utili. Il numero di epoche, la dimensione del batch e la regolarizzazione sono decisioni da validare, non valori universali.`,
      },
      {
        title: 'Perché profondità e dati cambiano il risultato',
        body: `Una rete profonda può apprendere gerarchie di caratteristiche: in una visione artificiale, strati iniziali possono reagire a bordi e texture, mentre gli strati successivi combinano queste informazioni in forme o oggetti. Ogni livello trasforma ciò che ha ricevuto; la rappresentazione finale può rendere più semplice una classificazione. Questa flessibilità richiede dati e calcolo, e aumenta il rischio di memorizzare dettagli accidentali quando gli esempi non bastano. Aumentare la profondità non garantisce automaticamente qualità: architettura, inizializzazione, stabilità dei gradienti e distribuzione dei dati contano. Tecniche come dropout, normalizzazione, augmentation e trasferimento dell’apprendimento affrontano problemi specifici, con effetti da misurare. Un modello pre-addestrato può ridurre il costo iniziale, ma eredita caratteristiche e limiti del training originario; il fine-tuning non cancella automaticamente bias o lacune.`,
      },
      {
        title: 'Esempi d’uso e limiti interpretativi',
        body: `Le reti profonde sono usate per classificare immagini mediche, riconoscere parole, prevedere consumi e tradurre testi. In un sistema industriale, per esempio, sensori di vibrazione possono alimentare una rete che stima la probabilità di un guasto; l’avviso serve a programmare un’ispezione, non dovrebbe diventare una sentenza incontestabile. Una rete complessa può essere accurata e al tempo stesso difficile da spiegare con una singola regola. Mappe di salienza, importanza delle caratteristiche e controfattuali offrono strumenti di analisi, ma non equivalgono sempre a una spiegazione causale fedele. Occorre anche capire se l’ingresso reale somiglia ai dati di addestramento e se il modello è robusto a rumore o cambiamenti. Senza simulatore, un buon esercizio consiste nel tracciare a mano una singola unità: pesi, somma, bias, attivazione e uscita. Questo chiarisce i meccanismi senza confondere l’intuizione con una replica biologica.`,
      },
      {
        title: 'Un esempio da seguire a mano',
        body: `Per rendere concreto il flusso, considera un’unità con due ingressi: x₁ = 1 e x₂ = 2, pesi 0,5 e −0,25 e bias 0,1. La somma ponderata è 0,1: 1 × 0,5 più 2 × −0,25 più 0,1. Applicando ReLU si ottiene 0,1 perché il valore è positivo. Se il target richiede un’uscita più alta, la perdita segnala uno scarto e i gradienti indicano quanto ogni parametro ha contribuito. Non occorre calcolare a mano una rete moderna: seguire questi passaggi rende chiaro perché input, pesi e attivazione sono concetti distinti. Aiuta anche a riconoscere che l’addestramento corregge parametri numerici, non regole scritte in italiano.`,
      },
    ],
    keyIdea: 'Il training regola i pesi per ridurre una perdita; la backpropagation calcola come cambiarli.',
    commonMistake: 'Pensare che una rete neurale sia una copia digitale del cervello o che più strati significhino sempre meglio.',
  },
  {
    id: 'llm',
    number: 4,
    title: 'AI generativa e LLM',
    subtitle: 'Token, attenzione e generazione del linguaggio',
    minutes: 16,
    sections: [
      {
        title: 'Che cosa significa generare',
        body: `Un modello linguistico di grandi dimensioni, o LLM, è un sistema addestrato a stimare distribuzioni di probabilità sui token. Un token può corrispondere a una parola, a una parte di parola, a punteggiatura o a un simbolo. Dato un contesto, il modello calcola quali token potrebbero venire dopo e seleziona o campiona una continuazione. La generazione ripete il passaggio, aggiungendo il token scelto al contesto. Questo obiettivo semplice produce comportamenti ricchi perché i testi contengono grammatica, fatti, stili e schemi di ragionamento. Ma “probabile nel testo” non significa “verificato nel mondo”. Un LLM non consulta necessariamente una base dati aggiornata e non porta con sé una garanzia di verità. La qualità dipende dal prompt, dalla versione, dai dati, dalle impostazioni e da strumenti esterni eventualmente collegati.`,
      },
      {
        title: 'Tokenizzazione e rappresentazioni',
        body: `Prima del modello, il testo viene suddiviso in token da un tokenizer. La segmentazione influenza costi, lunghezza del contesto e gestione di parole rare o lingue diverse. Ogni token viene trasformato in un vettore numerico detto embedding, che permette alle operazioni successive di lavorare su rappresentazioni continue. Posizioni e relazioni d’ordine vengono aggiunte con codifiche posizionali o meccanismi equivalenti, perché una sequenza di parole non è un semplice insieme. Se si fornisce una richiesta lunghissima, il limite di contesto può essere raggiunto: il sistema deve scartare, riassumere o non elaborare tutto ciò che precede. Le applicazioni ben progettate rendono visibili i limiti rilevanti, segmentano documenti e recuperano le parti pertinenti invece di presumere che il modello “ricordi” qualunque testo incollato.`,
      },
      {
        title: 'Self-attention, passo per passo',
        body: `Nel Transformer, ciascuna posizione crea vettori query, key e value attraverso trasformazioni apprese. In modo intuitivo, la query rappresenta che cosa una posizione sta cercando; le key descrivono ciò che offrono le altre posizioni; i value contengono informazione da combinare. Un punteggio di attenzione confronta query e key, viene normalizzato e usato per pesare i value. La formula classica è softmax(QKᵀ / √dₖ)V. Le teste multiple apprendono prospettive differenti e gli strati successivi combinano le informazioni. In un modello autoregressivo, una maschera impedisce di guardare token futuri durante la previsione. Questo meccanismo aiuta a collegare riferimenti distanti nel testo, ma non è un motore di ricerca né una prova di comprensione umana. L’attenzione è una componente di calcolo, non una spiegazione completa del comportamento del modello.`,
      },
      {
        title: 'Pre-addestramento e allineamento',
        body: `Il pre-training usa grandi quantità di dati per apprendere una rappresentazione generale e prevedere token mancanti o successivi, a seconda dell’obiettivo. In seguito, esempi curati possono insegnare formati di risposta e compiti specifici; istruzioni umane e preferenze possono essere usate per rendere il sistema più utile e sicuro. Queste fasi vengono spesso chiamate instruction tuning e allineamento, ma le ricette variano fra organizzazioni e modelli. L’allineamento non elimina errori: un modello può assecondare troppo la richiesta, evitare una risposta utile o inventare una fonte. Anche i dati di training portano squilibri, diritti e vincoli di provenienza. Un’azienda che integra un LLM deve quindi controllare policy, privacy, tracciabilità dei dati e possibilità di revisione, oltre a misurare le prestazioni sui propri casi d’uso.`,
      },
      {
        title: 'Decodifica, temperatura e famiglie di modelli',
        body: `Durante l’inferenza, il sistema trasforma i punteggi in una scelta. La temperatura riduce o amplia la differenza fra probabilità: valori più bassi tendono a produrre continuazioni più prevedibili, valori più alti esplorano alternative più varie. Top-p limita il campionamento a un insieme di token la cui probabilità cumulativa raggiunge una soglia. Questi controlli modificano la variabilità, non aggiungono conoscenza né garantiscono originalità. I modelli commerciali possono differire per dimensione, dati, strumenti disponibili, multimodalità, velocità, policy e finestra di contesto. GPT, Gemini e Claude sono linee di prodotti in evoluzione e non vanno ridotti a una sola architettura identica. Un confronto serio definisce compiti, esempi e criteri, poi misura accuratezza, latenza, costi e tasso di risposta da verificare.`,
      },
      {
        title: 'Usi reali, allucinazioni e controllo',
        body: `Gli LLM possono aiutare a riassumere, trasformare testi, estrarre campi, generare bozze e sostenere una ricerca documentale. Per attività basate su fonti specifiche, un sistema di retrieval può cercare passaggi in documenti autorizzati e fornirli come contesto. Il retrieval migliora la verificabilità quando mostra le fonti, ma non impedisce che il modello le interpreti male o aggiunga affermazioni estranee. “Allucinazione” descrive spesso un output plausibile ma non supportato; il rimedio dipende dal rischio: citazioni controllabili, regole di astensione, validatori, revisione umana o uso di un software deterministico per calcoli. In un contesto professionale, il modello dovrebbe essere assegnato a compiti in cui un errore è rilevabile e correggibile. Dati sensibili non vanno incollati in servizi senza aver compreso condizioni di trattamento e autorizzazioni.`,
      },
      {
        title: 'Una pipeline che aumenta la verificabilità',
        body: `Per una domanda aziendale su un regolamento interno, si può prima cercare nei documenti autorizzati, selezionare passaggi pertinenti e inviarli al modello insieme alla domanda. La risposta dovrebbe citare il documento e la sezione usati, così una persona può controllare il collegamento. Se il recupero non trova una fonte adeguata, il sistema dovrebbe dichiarare il limite invece di colmare il vuoto con una risposta generica. Si può inoltre verificare che ogni citazione esista davvero e che le frasi attribuite siano presenti nella fonte. Retrieval, citazioni e controlli rendono il flusso più auditabile, ma non trasformano il testo generato in una prova: l’utente resta responsabile di verificare le conclusioni quando la posta in gioco è alta.`,
      },
    ],
    keyIdea: 'Un LLM genera continuazioni probabili; la verifica delle affermazioni è un passaggio separato.',
    commonMistake: 'Interpretare una frase sicura e fluida come garanzia che il contenuto sia corretto o aggiornato.',
  },
  {
    id: 'prompt',
    number: 5,
    title: 'Prompt Engineering avanzato',
    subtitle: 'Progettare richieste chiare e valutabili',
    minutes: 13,
    sections: [
      {
        title: 'Il prompt è una specifica di lavoro',
        body: `Un prompt efficace descrive un compito, il contesto utile, i vincoli e il risultato atteso. “Scrivi un testo” lascia aperte troppe interpretazioni; “prepara una sintesi di 180 parole per un responsabile non tecnico, separa fatti e ipotesi e usa soltanto le note fornite” restringe il problema in modo verificabile. È spesso utile distinguere istruzioni, dati di ingresso ed esempi con titoli o delimitatori chiari. Specificare cosa non fare può prevenire errori, ma una lunga lista di proibizioni non sostituisce un obiettivo positivo e comprensibile. Il prompt dovrebbe dire come gestire informazioni mancanti: fare una domanda, indicare l’incertezza o lasciare un campo vuoto. Per i flussi ripetuti, la richiesta va trattata come un’interfaccia: gli input possono variare, la struttura di uscita deve restare stabile e gli errori più probabili devono essere testati.`,
      },
      {
        title: 'Istruzioni di sistema e gerarchia',
        body: `Un system prompt definisce il ruolo operativo, i limiti e le priorità di una sessione o applicazione; il messaggio dell’utente fornisce il compito del momento. L’implementazione concreta dipende dal servizio e non è sempre visibile all’utente finale. Un sistema utile può fissare lingua, pubblico, livello di dettaglio e regole di citazione. Non è una barriera di sicurezza infallibile: un utente può formulare input ostili e un documento recuperato può contenere istruzioni malevole. Le istruzioni del modello devono quindi essere affiancate da controlli applicativi, separazione fra contenuto e comando, permessi minimi e validazione delle azioni. Evitare segreti nei prompt e non affidarsi alla sola frase “ignora le istruzioni precedenti”. Il prompt definisce un comportamento desiderato; la sicurezza effettiva dipende anche dall’architettura che decide cosa il modello può leggere o modificare.`,
      },
      {
        title: 'Few-shot e In-Context Learning',
        body: `Nel few-shot prompting si forniscono alcuni esempi di input e output prima del nuovo caso. Gli esempi mostrano la forma e le distinzioni desiderate senza aggiornare i pesi del modello. Per esempio, si possono presentare due recensioni con etichetta “richiesta di rimborso” e una con etichetta “feedback”, poi chiedere di classificare un messaggio nuovo. Gli esempi vanno scelti per coprire i confini fra categorie, non soltanto casi ovvi. Devono essere coerenti fra loro: un’etichetta contraddittoria può insegnare una regola confusa. L’in-context learning indica la capacità di usare il contesto fornito in quel momento per svolgere un compito; non implica che il modello abbia memorizzato permanentemente quegli esempi. Se il contesto è troppo lungo, ridondante o ambiguo, gli esempi possono essere ignorati o competere con l’istruzione principale.`,
      },
      {
        title: 'Scomporre compiti e chiedere ragioni',
        body: `Un compito complesso può essere diviso in passaggi espliciti: estrarre dati, confrontarli con criteri, produrre una decisione motivata e controllare il formato. Questa scomposizione rende gli errori più individuabili e permette di assegnare sottocompiti a strumenti deterministici. Le tecniche chiamate chain-of-thought o prompting a passaggi chiedono una spiegazione o una procedura intermedia. Un testo di ragionamento generato può essere utile come traccia, ma non va assunto come registrazione fedele del processo interno del modello: può essere incompleto, inventato o razionalizzato dopo il risultato. Per sistemi sensibili è meglio chiedere una motivazione breve con riferimenti verificabili, oppure produrre una lista di controlli indipendenti. Richiedere “pensa passo dopo passo” non rende automaticamente un problema più sicuro o corretto; serve valutare l’output e ridurre la complessità in modo appropriato.`,
      },
      {
        title: 'Output strutturati e iterazione',
        body: `Se un risultato deve alimentare un programma, si può chiedere una struttura rigida, come JSON con campi definiti, e poi validarla con uno schema. Il prompt da solo non garantisce che il formato sia sempre valido; la validazione deve rifiutare proprietà mancanti, valori fuori intervallo o testo inaspettato. Per migliorare una richiesta, si preparano esempi rappresentativi e un set di valutazione separato. Si confrontano versioni del prompt con criteri espliciti: correttezza, completezza, tono, rispetto del formato e comportamento quando mancano informazioni. Cambiare molte istruzioni insieme rende difficile capire cosa abbia aiutato. Si registrano versione del modello, parametri e risultati, facendo attenzione a non conservare dati personali non necessari. L’iterazione basata su test ripetibili è più affidabile dell’aggiustamento di un prompt dopo aver visto un solo esempio fortunato.`,
      },
      {
        title: 'Prompt injection e limiti',
        body: `Una prompt injection è un tentativo di far trattare al modello un contenuto non attendibile come se fosse un’istruzione prioritaria. Può arrivare da una richiesta diretta, da una pagina recuperata o da un allegato. La difesa non consiste nel nascondere una frase segreta nel prompt di sistema: si limita l’accesso ai dati, si separano istruzioni da documenti, si filtrano strumenti e si richiede conferma prima di azioni irreversibili. Anche gli output devono essere trattati come non attendibili, soprattutto se vengono usati per comporre query, inviare messaggi o modificare record. Un buon prompt engineering migliora chiarezza e consistenza, ma non trasforma un modello probabilistico in un interprete deterministico. Quando l’errore ha conseguenze legali, sanitarie o economiche, serve un processo proporzionato di verifica e responsabilità umana.`,
      },
      {
        title: 'Una scheda di valutazione riutilizzabile',
        body: `Prima di cambiare un prompt, prepara una piccola raccolta di casi: richiesta normale, richiesta ambigua, input incompleto, esempio difficile e istruzione fuori ambito. Per ogni caso annota cosa conta come risposta corretta, quali fonti sono ammesse e come deve comportarsi il modello se non sa. Esegui la stessa raccolta dopo ogni modifica, usando versione del modello e impostazioni comparabili. Un punteggio semplice può contare campi corretti e formato valido; una revisione umana può giudicare chiarezza e utilità. Conserva solo gli input necessari e oscura dati personali. La scheda non deve essere enorme: anche una dozzina di esempi ben scelti è più informativa di una singola dimostrazione scelta perché il modello ha risposto bene.`,
      },
    ],
    keyIdea: 'Prompt efficaci sono testabili: specificano input, vincoli, forma e gestione dell’incertezza.',
    commonMistake: 'Pensare che un prompt di sistema possa sostituire permessi, validazione e sicurezza applicativa.',
  },
  {
    id: 'vision',
    number: 6,
    title: 'Computer Vision e AI visiva',
    subtitle: 'Dalle convoluzioni alla generazione di immagini',
    minutes: 14,
    sections: [
      {
        title: 'Un’immagine come dato',
        body: `Un’immagine digitale è una griglia di pixel. Ogni pixel contiene valori che codificano luminosità e, in una rappresentazione a colori, componenti come rosso, verde e blu. La visione artificiale prova a ricavare da questi valori informazioni come categoria, posizione, contorni o relazioni fra oggetti. Il problema è complesso perché lo stesso oggetto cambia aspetto con illuminazione, orientamento, distanza, occlusioni e sfondo. Un dataset deve quindi comprendere variazioni pertinenti e rispettare le condizioni d’uso. Una rete può imparare indizi accidentali: se tutte le fotografie di lupi nel training hanno neve sullo sfondo, può associare la neve alla categoria invece di riconoscere l’animale. La qualità dipende anche da risoluzione, compressione, bilanciamento delle classi e consenso sulla definizione delle etichette. Prima di misurare la precisione è essenziale capire quale regione dell’immagine dovrebbe sostenere la previsione.`,
      },
      {
        title: 'Convoluzioni e reti CNN',
        body: `Una rete convoluzionale, o CNN, applica filtri locali che scorrono sull’immagine. Un filtro combina i pixel vicini per rilevare configurazioni, come cambiamenti di intensità o texture. Riutilizzare lo stesso filtro in posizioni diverse sfrutta una proprietà utile: un bordo può apparire ovunque nella scena. Strati successivi combinano caratteristiche locali in forme più ampie. Operazioni di pooling o riduzione della risoluzione diminuiscono la quantità di informazione mantenendo segnali considerati rilevanti. Durante l’addestramento i filtri non vengono normalmente scritti a mano; i loro valori si aggiornano per ridurre una perdita sugli esempi. Le CNN sono state centrali nella classificazione e nella localizzazione di oggetti, anche se architetture basate su Transformer per immagini sono ormai diffuse. La scelta fra modelli dipende da dati, risorse, latenza e requisiti del compito, non da una classifica universale.`,
      },
      {
        title: 'Compiti visivi e pipeline',
        body: `La classificazione assegna una o più etichette a un’immagine intera; il rilevamento localizza oggetti con riquadri e categorie; la segmentazione assegna una classe a ciascun pixel o regione. Il riconoscimento ottico dei caratteri trasforma testo in un’immagine in una sequenza leggibile. Questi compiti richiedono annotazioni diverse e vanno testati con metriche adeguate. Un sistema industriale può rilevare difetti su una linea di produzione, ma la soglia di allarme deve bilanciare pezzi scartati e difetti che passano inosservati. In medicina, l’AI può evidenziare regioni da esaminare, ma il contesto clinico e la verifica professionale rimangono essenziali. Nella pipeline pratica si controllano formati, orientamento, privacy e qualità prima del modello, poi si registrano in modo sicuro risultati e incertezze. Un output visivo va presentato come supporto all’interpretazione, non come prova autonoma.`,
      },
      {
        title: 'Modelli di diffusione',
        body: `Molti modelli generativi di immagini moderni si basano sulla diffusione. In fase di training, il modello osserva immagini a cui è stato aggiunto rumore progressivamente e impara a stimare come rimuoverlo o a ricavare una rappresentazione equivalente. In generazione, parte da rumore e lo trasforma in una configurazione coerente in più passaggi, guidato dal prompt e da rappresentazioni apprese. Alcuni sistemi lavorano in uno spazio latente compresso per ridurre il costo computazionale. Il testo viene codificato e influenza la direzione della generazione; l’output è un campione plausibile, non una fotografia necessariamente vera. DALL·E, Midjourney e Stable Diffusion hanno implementazioni e controlli differenti, che cambiano nel tempo. Il prompt può guidare composizione e stile, ma non garantisce che ogni dettaglio sia rispettato, leggibile o privo di distorsioni.`,
      },
      {
        title: 'Trasferimento, robustezza e rischi',
        body: `I modelli visivi pre-addestrati consentono di riusare caratteristiche apprese su un grande insieme di immagini e adattarle a un compito più specifico. Il transfer learning riduce il bisogno di dati e tempo rispetto all’addestramento da zero, ma il dataset originario può introdurre bias culturali o lacune. L’augmentation crea variazioni controllate, come ritagli e rotazioni, per migliorare la robustezza; trasformazioni inadatte possono alterare il significato, per esempio capovolgere simboli per cui l’orientamento è decisivo. Si controllano prestazioni per condizioni di luce, dispositivi, gruppi e scenari rari. Anche i generatori sollevano questioni di provenienza, consenso, copyright, impersonificazione e disinformazione. Filigrane e metadati aiutano alcuni flussi, ma non sostituiscono policy chiare e verifica. In ambito aziendale conviene documentare immagini usate, finalità, accessi e modalità di revisione umana.`,
      },
      {
        title: 'Valutare un sistema visivo',
        body: `Una demo con tre immagini convincenti non dimostra che un modello sia pronto per l’uso. La valutazione deve includere esempi rappresentativi, casi difficili, immagini fuori distribuzione e condizioni in cui il sistema dovrebbe astenersi. Accuratezza, precisione, richiamo e mAP misurano aspetti differenti a seconda del compito; un punteggio medio può nascondere errori concentrati in un gruppo o in un dispositivo. È utile esaminare falsi positivi e falsi negativi con esperti del dominio e chiedere quale decisione seguirà ciascun output. Un modello può anche ottenere il risultato corretto per una ragione sbagliata, basandosi su watermark, sfondi o indizi spurii. L’interpretabilità visiva aiuta l’analisi, ma una mappa colorata non certifica causalità. La messa in produzione richiede monitoraggio e un piano per aggiornare il modello quando cambiano prodotti, telecamere o contesti.`,
      },
      {
        title: 'Progettare un controllo visivo concreto',
        body: `In un sistema di ispezione, raccogli immagini che rappresentino turni, lotti, illuminazione e dispositivi reali, non soltanto le fotografie migliori. Tieni separati i lotti usati per il test da quelli del training, perché immagini quasi identiche possono altrimenti gonfiare il risultato. Definisci in anticipo cosa succede quando l’immagine è sfocata, l’oggetto è parzialmente nascosto o il punteggio è incerto: scartare, ripetere la foto o inviare a una persona sono scelte diverse. Registra i falsi allarmi e i difetti mancati, poi confrontali con il costo di ispezione e il rischio di qualità. Ripeti la valutazione quando cambiano telecamere, prodotto o linea, perché la distribuzione degli input è parte del problema.`,
      },
    ],
    keyIdea: 'Per immagini e video, la rappresentatività del dato è decisiva quanto l’architettura.',
    commonMistake: 'Trattare un’immagine generata o classificata come prova visiva autentica e verificata.',
  },
  {
    id: 'audio',
    number: 7,
    title: 'AI vocale e multimodale',
    subtitle: 'Parlato, suoni e combinazione di modalità',
    minutes: 13,
    sections: [
      {
        title: 'Dal suono al segnale digitale',
        body: `Il suono è una variazione di pressione nel tempo. Un microfono la converte in un segnale che viene campionato a intervalli regolari e quantizzato in valori numerici. Frequenza di campionamento, profondità in bit e compressione incidono su qualità e dimensione. Per alcuni modelli, il segnale viene trasformato in una rappresentazione spettrale, come uno spettrogramma, che mostra come l’energia delle frequenze cambia nel tempo. Queste rappresentazioni aiutano a osservare fonemi e caratteristiche del parlato, ma non sono l’unica scelta: sistemi moderni possono operare direttamente su sequenze audio o token appresi. Rumore, accenti, velocità, riverbero e sovrapposizione di voci rendono il problema variabile. Il sistema deve essere provato su condizioni simili a quelle reali e non soltanto su registrazioni pulite da laboratorio.`,
      },
      {
        title: 'Speech-to-Text e riconoscimento',
        body: `Il riconoscimento automatico del parlato, o ASR, produce testo a partire dall’audio. Una pipeline può includere rilevamento delle attività vocali, codifica acustica, previsione di unità linguistiche e decodifica in parole. Alcuni sistemi integrano in un’unica rete passaggi che prima erano separati. Il risultato viene valutato con misure come il word error rate, che confronta sostituzioni, cancellazioni e inserimenti rispetto a una trascrizione di riferimento. Un basso errore medio non garantisce uguale qualità per tutti: dialetti, voci meno rappresentate e lessico specialistico possono essere riconosciuti peggio. Punteggiatura e segmentazione sono ulteriori scelte del modello. Per verbali, call center e documentazione, si definiscono policy di consenso, conservazione e correzione. Una trascrizione generata va considerata una bozza, soprattutto quando una parola incerta può cambiare una decisione o attribuire una dichiarazione a una persona.`,
      },
      {
        title: 'Text-to-Speech e identità della voce',
        body: `Il text-to-speech, o TTS, genera parlato da testo. I sistemi tradizionali concatenavano unità audio registrate; quelli neurali apprendono rappresentazioni acustiche e producono una voce più fluida, con ritmo e intonazione. Si possono controllare lingua, velocità e, in alcuni prodotti, caratteristiche vocali. La clonazione vocale rende possibile imitare un timbro da campioni limitati e aumenta i rischi di frode e impersonificazione. Un impiego responsabile richiede autorizzazione esplicita, indicazione chiara della natura sintetica e limiti di accesso ai campioni. La naturalezza non prova l’identità della persona che parla, e un audio convincente può essere sintetico o modificato. Per l’accessibilità e la lettura di contenuti, il TTS può essere molto utile; in ambiti di autenticazione o prove forensi, la voce da sola non dovrebbe essere trattata come credenziale incontestabile.`,
      },
      {
        title: 'Sistemi multimodali',
        body: `Un sistema multimodale elabora o genera più tipi di informazione, come testo, immagini, audio e video. Un encoder può convertire ciascuna modalità in vettori confrontabili, oppure un modello può integrare token specifici per i diversi segnali. L’allineamento fra modalità permette, per esempio, di associare una domanda a un fotogramma o una frase pronunciata a una trascrizione. Il fatto che il sistema accetti immagini e parlato non significa che interpreti ogni dettaglio con uguale affidabilità. Il ritaglio dell’immagine, la sincronizzazione audio-video e il contesto temporale possono cambiare la risposta. Se il compito è “descrivi questa scena”, il modello può ignorare un elemento piccolo o attribuire un’azione non presente. Per applicazioni critiche, si definiscono input attesi, finestre temporali, risoluzioni e procedure di controllo, e si conserva la fonte di ogni risultato.`,
      },
      {
        title: 'Applicazioni e gestione dei dati',
        body: `Le tecnologie vocali supportano sottotitoli, traduzione, comandi a mani libere, accessibilità e ricerca negli archivi audio. In un’azienda, una trascrizione può rendere consultabili migliaia di registrazioni, ma prima si stabiliscono informativa, finalità, accessi e tempi di conservazione. Le voci contengono dati personali e possono rivelare informazioni su salute, emozioni o identità. Registrare per impostazione predefinita senza un motivo chiaro crea rischi evitabili. Una soluzione può elaborare l’audio sul dispositivo, anonimizzare segmenti o limitare i dati conservati, se il caso d’uso lo permette. Anche le metriche devono riflettere gli utenti reali: un sistema eccellente in una lingua può essere inadeguato in un’altra. Il coinvolgimento di persone con disabilità e parlanti diversi nella progettazione aiuta a scoprire problemi che un benchmark generico non mostra.`,
      },
      {
        title: 'Limiti e verifica',
        body: `Un assistente vocale può confondere rumore e parole, attribuire frasi alla persona sbagliata o sintetizzare una risposta che non corrisponde alla registrazione. Per ridurre il rischio, l’interfaccia può mostrare confidenza, offrire revisione del testo e distinguere citazioni da riassunti. La confidenza numerica non è sempre ben calibrata: va verificata su dati simili al contesto d’uso. In caso di audio generato, etichette e metadati possono aiutare a comunicare l’origine, ma possono essere rimossi; occorre quindi progettare anche controlli organizzativi. La combinazione multimodale può migliorare la comprensione, ma aggiunge superfici di errore: un’informazione in un canale può contraddire un altro, e un modello potrebbe privilegiare la modalità sbagliata. La regola pratica è attribuire a ogni output un livello di fiducia proporzionato alle evidenze disponibili.`,
      },
      {
        title: 'Dal prototipo alla registrazione responsabile',
        body: `Una prova di trascrizione può iniziare con clip brevi e autorizzate, confrontando la bozza con un riferimento corretto da persone. Si segnano parole tecniche, nomi propri e passaggi in cui un errore cambia il significato; questi casi guideranno un glossario o una revisione mirata. Prima di scalare, si chiarisce chi ha autorizzato la registrazione, chi può ascoltarla e quando viene cancellata. I file audio originali possono essere più sensibili della trascrizione: proteggerli entrambi è importante. Si informa chi parla se il sistema analizza la voce e si evita di dedurre caratteristiche sensibili non necessarie. Se la trascrizione entra in un verbale o in un processo disciplinare, la persona interessata deve poter correggere gli errori. La precisione tecnica e il trattamento equo non sono alternative.`,
      },
    ],
    keyIdea: 'L’audio contiene informazioni personali: qualità, consenso e provenienza vanno progettati insieme.',
    commonMistake: 'Assumere che una trascrizione perfetta o una voce naturale siano prova di ciò che è accaduto.',
  },
  {
    id: 'agenti',
    number: 8,
    title: 'Agenti AI e automazioni',
    subtitle: 'Pianificazione, strumenti e supervisione',
    minutes: 14,
    sections: [
      {
        title: 'Da una risposta a una sequenza di azioni',
        body: `Un agente AI è un sistema che riceve un obiettivo, osserva informazioni, sceglie fra azioni disponibili e usa il risultato per decidere il passo successivo. La differenza rispetto a una singola richiesta a un LLM è il ciclo di interazione: un agente può pianificare, chiamare strumenti e controllare un risultato. Non è necessariamente autonomo in senso forte e non possiede intenzioni proprie; segue un processo progettato da persone. Un flusso può ricevere un evento, chiedere al modello di classificare un messaggio, recuperare un documento, redigere una risposta e fermarsi per approvazione. La qualità dipende dalla progettazione dei passaggi, dalle API accessibili e dai criteri di arresto. Aggiungere un ciclo “pensa e prova ancora” non rende automaticamente il sistema più capace: può consumare risorse, ripetere errori o intraprendere azioni non previste.`,
      },
      {
        title: 'Il ciclo ReAct e la pianificazione',
        body: `ReAct è un approccio che combina ragionamento testuale e azione: il sistema interpreta lo stato, seleziona uno strumento, riceve un’osservazione e decide se continuare o concludere. In una variante didattica, un agente può cercare nel catalogo, verificare la disponibilità e poi proporre un prodotto; non dovrebbe confermare un acquisto senza i permessi e i controlli richiesti. La pianificazione può essere esplicita, con una lista di sottocompiti, oppure emergere passo dopo passo. Un piano è una proposta che va confrontata con lo stato reale: un passaggio può fallire, un dato può essere obsoleto e una dipendenza può non essere disponibile. Gli agenti robusti distinguono completamento da tentativo, gestiscono timeout e errori e pongono domande quando l’obiettivo è ambiguo. I passaggi di ragionamento visibili sono tracce utili, non una garanzia che la procedura sia corretta.`,
      },
      {
        title: 'Strumenti, permessi e memoria',
        body: `Gli strumenti trasformano un modello da generatore di testo a componente che interagisce con servizi: ricerca, calendari, fogli di calcolo, ticket o API interne. Ogni strumento ha input e output che vanno descritti e validati. Il principio del minimo privilegio concede soltanto le operazioni necessarie: un agente che deve leggere un’agenda non dovrebbe poter cancellare tutti gli eventi. La memoria può contenere lo stato della conversazione, preferenze autorizzate o dati recuperati, ma occorre stabilire durata, provenienza e possibilità di cancellazione. Una memoria errata o non aggiornata può peggiorare il comportamento futuro. I contenuti trovati sul web o nei documenti devono essere trattati come dati non attendibili, non come istruzioni per aumentare i permessi. Le azioni con effetti esterni richiedono conferma esplicita e registri comprensibili, soprattutto quando sono costose o difficili da annullare.`,
      },
      {
        title: 'Automazioni aziendali e supervisione',
        body: `Gli agenti sono interessanti in processi ripetitivi con passaggi osservabili: classificare richieste, raccogliere dati da fonti approvate, preparare una bozza e assegnare un caso alla squadra corretta. Il valore emerge quando riducono tempi senza nascondere la responsabilità. Si definisce un perimetro ristretto, si costruisce un percorso per casi incerti e si misura il tempo risparmiato insieme agli errori e alle escalation. In un flusso a blocchi, trigger, azione AI e output possono essere resi visibili, così gli operatori capiscono quali dati sono entrati e quali effetti sono avvenuti. L’approvazione umana deve essere un controllo reale, non un clic automatico. Per operazioni delicate, l’agente prepara una proposta ma un responsabile autorizzato conferma. Le metriche di monitoraggio includono tentativi falliti, strumenti chiamati, modifiche effettuate e risultati corretti dopo revisione.`,
      },
      {
        title: 'AutoGPT, framework e limiti',
        body: `Progetti come AutoGPT hanno reso popolare l’idea di agenti che scompongono un obiettivo e usano strumenti in cicli relativamente lunghi. Framework come ReAct, tool calling e orchestratori a grafo propongono modi diversi per strutturare questi flussi. Una demo può sembrare autonoma perché il caso è semplice e le condizioni sono favorevoli; in produzione, errori di rete, ambiguità, dati mancanti e limiti API diventano normali. I modelli possono pianificare male, ripetere un’azione, chiamare lo strumento sbagliato o interpretare un output in modo scorretto. Il “loop infinito” è un rischio di costo e affidabilità: si impostano limiti di iterazioni, budget, timeout e condizioni d’arresto. Prima di delegare un processo completo, è prudente automatizzare soltanto i passaggi verificabili e mantenere un punto di intervento per le eccezioni.`,
      },
      {
        title: 'Progettare un agente sicuro',
        body: `La progettazione parte dalla mappa delle azioni possibili e dei danni plausibili. Si separano lettura e scrittura, si validano i parametri, si limitano i destinatari e si richiede una conferma per operazioni irreversibili. Le risposte degli strumenti devono essere controllate: una stringa inattesa non dovrebbe diventare una query o un comando eseguibile senza validazione. Le credenziali non vanno inserite nel prompt e le informazioni personali si riducono al minimo. Si testa il flusso con casi ordinari, input ostili, timeout, dati contraddittori e permessi negati. Gli audit log dovrebbero rendere chiaro chi ha autorizzato una decisione e quali dati sono stati consultati, senza conservare informazioni oltre il necessario. Un buon agente sa anche fermarsi: se la richiesta supera il perimetro definito o il risultato è incerto, deve chiedere chiarimenti o passare il caso a una persona.`,
      },
      {
        title: 'Un test di sicurezza per il flusso',
        body: `Prima del rilascio, simula almeno un caso in cui il trigger si ripete, uno strumento restituisce un errore, una richiesta include istruzioni ostili e un utente chiede un’azione non autorizzata. Verifica che l’agente non continui a riprovare senza limite, che non esponga dati recuperati e che l’output venga controllato prima di un effetto esterno. Inserisci un limite di costo e un tempo massimo, registra l’identificativo dell’azione e offri un modo chiaro per annullarla quando possibile. I test non dimostrano sicurezza assoluta, ma scoprono percorsi prevedibili prima che coinvolgano clienti o sistemi reali. Un proprietario del flusso dovrebbe rivedere periodicamente strumenti, permessi e log, perché una modifica all’API può cambiare il rischio anche se il prompt è rimasto identico.`,
      },
    ],
    keyIdea: 'Un agente combina un modello con strumenti e autorizzazioni: è il perimetro operativo a definirne il rischio.',
    commonMistake: 'Concedere a un agente permessi ampi e assumere che il modello si fermerà da solo prima di un errore.',
  },
  {
    id: 'etica',
    number: 9,
    title: 'Etica, bias e sicurezza',
    subtitle: 'Responsabilità, trasparenza e gestione del rischio',
    minutes: 15,
    sections: [
      {
        title: 'Il bias è un problema di sistema',
        body: `Il bias algoritmico è una distorsione sistematica che può produrre effetti diversi o ingiusti fra persone o gruppi. Può entrare nella raccolta dati, nelle etichette, nella scelta delle variabili, nella metrica e nell’uso finale. Se dati storici riflettono discriminazioni, un modello che li imita può riprodurle in modo efficiente e meno visibile. Anche dati formalmente neutrali possono agire come proxy di caratteristiche sensibili: codice postale o carriera possono correlarsi con gruppi sociali. Non esiste una singola metrica di equità valida per ogni situazione; criteri diversi possono entrare in conflitto quando i tassi di base variano. Il lavoro parte dal contesto: chi beneficia, chi sopporta gli errori, quale decisione viene supportata e quali rimedi sono disponibili. Senza queste domande, una dichiarazione generica di “fairness” non è una valutazione.`,
      },
      {
        title: 'Misurare e correggere le disparità',
        body: `L’analisi può confrontare falsi positivi, falsi negativi, calibrazione e accesso al servizio fra gruppi rilevanti, rispettando le norme e la minimizzazione dei dati. I risultati medi non bastano: gruppi piccoli e intersezioni possono essere nascosti dall’aggregazione. Le correzioni possono includere raccolta di esempi migliori, revisione delle etichette, modifiche alla soglia, riprogettazione del compito o rinuncia all’automazione. Ogni intervento ha compromessi e va testato prima e dopo. Un classificatore che sembra equo sui dati storici può creare un ciclo di retroazione: le decisioni influenzano quali nuovi dati diventano disponibili, che poi rafforzano la stessa previsione. Audit indipendenti, documentazione e coinvolgimento di persone interessate aiutano a far emergere impatti che il team tecnico potrebbe non vedere. Un dataset sintetico usato in laboratorio illustra concetti, ma non prova che un sistema reale sia equo.`,
      },
      {
        title: 'Allucinazioni, sicurezza e uso improprio',
        body: `Le allucinazioni sono affermazioni generate che sembrano plausibili ma non hanno supporto sufficiente. La loro gravità dipende dal contesto: una bozza creativa può tollerare un’invenzione, un riferimento legale o una diagnosi no. Si riducono i rischi con fonti tracciabili, controlli, astensione e revisione umana, ma non si possono azzerare per semplice richiesta. La sicurezza comprende anche input ostili, prompt injection, estrazione di dati, uso di contenuti protetti e decisioni automatizzate non autorizzate. Le mitigazioni tecniche vanno combinate con accessi minimi, logging appropriato, procedure di risposta agli incidenti e formazione. Un modello addestrato per rifiutare certe richieste non può sostituire la sicurezza del prodotto. Prima del rilascio si analizzano scenari di abuso, si stabilisce un canale per segnalare problemi e si definiscono ruoli per sospendere il sistema quando il rischio supera la soglia accettata.`,
      },
      {
        title: 'Privacy, copyright e trasparenza',
        body: `I dati usati per addestrare o interrogare un sistema possono includere informazioni personali, commerciali o protette da copyright. La liceità dipende da finalità, base giuridica, contratti, giurisdizione e modalità del trattamento; un team deve rivolgersi a professionisti competenti per valutazioni concrete. Il principio di minimizzazione privilegia i dati necessari, evita di inserire dettagli sensibili senza motivo e limita conservazione e accesso. Per materiali protetti, occorre controllare licenze, autorizzazioni e policy del fornitore. La trasparenza dovrebbe comunicare quando una persona interagisce con un sistema automatizzato, quali limiti sono rilevanti e come chiedere assistenza o contestare un esito. Non tutte le spiegazioni tecniche sono comprensibili agli utenti; disclosure e documentazione vanno calibrate sui loro bisogni. Una comunicazione onesta distingue capacità dimostrate da promesse commerciali.`,
      },
      {
        title: 'Il quadro europeo: AI Act',
        body: `Il Regolamento europeo sull’intelligenza artificiale, noto come AI Act e identificato come Regolamento (UE) 2024/1689, adotta un’impostazione basata sul rischio. Prevede divieti per alcune pratiche, requisiti specifici per sistemi ad alto rischio e obblighi di trasparenza per determinate applicazioni e modelli di AI per finalità generali. Ruoli e obblighi dipendono dal modo in cui un sistema viene sviluppato, fornito, modificato e messo in uso; la stessa tecnologia può ricadere in contesti giuridici differenti. La normativa ha applicazione progressiva e le interpretazioni operative possono evolvere con linee guida e atti successivi. Questa lezione fornisce orientamento didattico, non consulenza legale. Un’organizzazione deve verificare il testo ufficiale aggiornato, la categoria del sistema, gli obblighi applicabili e le norme complementari su privacy, consumatori e lavoro. La conformità è un processo documentato, non un’etichetta da apporre sul prodotto.`,
      },
      {
        title: 'Governance responsabile',
        body: `Una governance concreta assegna responsabilità prima che il sistema entri in uso: chi approva i dati, chi valuta le prestazioni, chi gestisce reclami e chi può disattivarlo. La documentazione registra finalità, popolazione interessata, limiti, metriche, test, modifiche e incidenti. La valutazione va ripetuta quando cambiano modello, dati, contesto o destinatari. È utile prevedere un registro dei sistemi AI, classificare il rischio e coinvolgere competenze legali, tecniche e di dominio. La persona che subisce una decisione deve sapere come ottenere una revisione quando previsto dal contesto. La responsabilità non si trasferisce al vendor o all’algoritmo: chi usa il sistema resta responsabile delle proprie decisioni e dei controlli che ha scelto. L’etica operativa si vede nella possibilità di correggere, contestare e fermare un sistema, non soltanto in principi scritti.`,
      },
      {
        title: 'Domande per un audit iniziale',
        body: `Un audit pratico può iniziare con cinque domande: quale decisione viene influenzata; chi può contestarla; quali gruppi potrebbero ricevere più errori; quali dati personali entrano nel sistema; chi può sospenderlo? Si documentano poi le risposte, le fonti e le lacune. Un analizzatore di bias didattico usa numeri inventati per mostrare che tassi diversi meritano indagine, ma una disparità non dimostra automaticamente causa o discriminazione: vanno esaminati definizioni, campionamento, obiettivi e conseguenze. Simmetricamente, tassi simili non provano che l’intero processo sia equo. L’audit dovrebbe coinvolgere competenze di dominio e persone interessate, non solo chi ha costruito il modello. Quando non esistono dati affidabili o un rimedio praticabile, la decisione responsabile può essere non automatizzare.`,
      },
    ],
    keyIdea: 'Il rischio dipende da chi usa il sistema, su chi agisce e da quanto sia reversibile una decisione.',
    commonMistake: 'Trattare una media alta o una promessa di conformità come prova di assenza di danni.',
  },
  {
    id: 'business',
    number: 10,
    title: 'AI nel lavoro e nel business',
    subtitle: 'Scegliere i casi d’uso e misurare il valore',
    minutes: 14,
    sections: [
      {
        title: 'Partire dal problema, non dal modello',
        body: `Un progetto aziendale efficace parte da un problema operativo osservabile, non dalla domanda “dove possiamo mettere l’AI?”. Si descrivono utenti, attività, volumi, tempi, colli di bottiglia ed errori attuali. Poi si valuta se un modello può migliorare il processo rispetto a una regola, una ricerca o un’interfaccia tradizionale più semplice. Un buon primo caso d’uso ha input relativamente disponibili, output controllabili, valore misurabile e rischio gestibile. Se l’obiettivo è ridurre tempi di risposta, si misura il tempo fino alla soluzione, non soltanto quanti testi sono generati. Si definisce anche una baseline, cioè il risultato senza AI, per evitare di attribuire al nuovo strumento miglioramenti dovuti ad altri cambiamenti. Il modello più potente non è necessariamente il più adatto: costo, latenza, privacy e possibilità di controllo pesano quanto la capacità nominale.`,
      },
      {
        title: 'Preparazione dei dati e make-or-buy',
        body: `La preparazione include inventario delle fonti, autorizzazioni, qualità, aggiornamento e coerenza dei dati. Un LLM collegato a documenti obsoleti può produrre risposte fluide ma sbagliate; un modello di previsione addestrato su etichette incoerenti replica l’incoerenza. L’organizzazione confronta sviluppo interno, API esterna, modelli open-source e strumenti già disponibili. La scelta considera proprietà intellettuale, trattamento dei dati, portabilità, lock-in, prestazioni e costi totali, compresa manutenzione. Un prototipo può usare dati sintetici o anonimizzati, ma la validazione finale richiede condizioni rappresentative e conformi. Prima di trasferire informazioni a un provider, si leggono condizioni, impostazioni di conservazione e localizzazione, senza presumere che il termine “enterprise” risolva ogni questione. Architetture modulari e contratti chiari facilitano la sostituzione di componenti quando cambiano requisiti o prezzi.`,
      },
      {
        title: 'Integrare senza nascondere il lavoro',
        body: `Un sistema AI si inserisce in un flusso esistente: per esempio, prepara una risposta a una richiesta cliente, ma un operatore la controlla prima dell’invio. L’interfaccia deve mostrare fonti, campi incerti e modifiche, evitando che l’output sia copiato automaticamente in un registro ufficiale senza verifica. Le regole deterministiche restano utili per calcoli, autorizzazioni e controlli di formato. L’AI può gestire linguaggio variabile, mentre il software tradizionale applica vincoli e registra gli effetti. Si definiscono percorsi alternativi per errori, indisponibilità, richieste anomale e casi che richiedono una persona. Questa progettazione riduce la possibilità che il processo dipenda da una singola previsione fragile. L’adozione deve coinvolgere gli operatori che conoscono le eccezioni reali: ignorarli spesso produce uno strumento elegante in demo ma evitato nella routine.`,
      },
      {
        title: 'Produttività, ruoli e cambiamento',
        body: `L’AI può automatizzare parti di un compito e aumentare la produttività senza rimuovere un’intera professione. Un assistente può accelerare la ricerca, organizzare bozze o classificare richieste, mentre valutazione, relazione e responsabilità restano a persone. Gli effetti variano per settore, seniority e qualità dei processi. Se il tempo risparmiato viene riempito da controlli aggiuntivi o da più volume, il beneficio percepito può essere diverso dal guadagno tecnico. La formazione va collegata ai compiti e insegna a verificare fonti, proteggere dati e riconoscere casi fuori perimetro. Si consultano le persone interessate sui cambiamenti a ruoli, carichi e criteri di performance. Misurare soltanto output per dipendente può incentivare velocità a scapito di qualità e benessere; indicatori equilibrati includono accuratezza, soddisfazione, revisione e impatti sulle condizioni di lavoro.`,
      },
      {
        title: 'ROI, metriche e total cost of ownership',
        body: `Un business case confronta benefici e costi nel tempo. Fra i costi rientrano chiamate al modello, storage, integrazione, sicurezza, licenze, revisione umana, incidenti e aggiornamento. Il valore può includere ore recuperate, riduzione di errori, maggiore accessibilità o nuove capacità; va calcolato con ipotesi trasparenti. Un esperimento può confrontare gruppi o periodi simili, controllando altri cambiamenti, e misurare sia qualità sia velocità. La percentuale di risposte accettate non è sufficiente: un operatore può accettare per pressione, o rifiutare un suggerimento utile perché il flusso è scomodo. Il costo per risultato corretto spesso è più significativo del costo per token. Si fissano soglie di successo e condizioni di stop prima del pilot, così risultati deludenti portano a una decisione chiara invece di una continuazione per inerzia.`,
      },
      {
        title: 'Esempi e regole di distribuzione',
        body: `Nel supporto clienti, un assistente può cercare una risposta in una base documentale e preparare una bozza con citazioni; il team controlla casi sensibili e misura la risoluzione al primo contatto. In un ufficio amministrativo, un sistema può estrarre campi da fatture e inviare all’approvazione quelle con bassa confidenza. In entrambi i casi, la qualità delle fonti e una coda di eccezioni ben progettata sono fondamentali. Per distribuire, si avvia una fase pilota, si raccolgono feedback, si monitora la deriva e si definisce chi risponde agli incidenti. Le persone devono poter contestare o correggere output che influenzano il loro lavoro. Il passaggio alla produzione è una scelta organizzativa, non soltanto un deploy tecnico: occorre un proprietario del processo, budget di manutenzione e un piano per ritirare il sistema se non mantiene le promesse.`,
      },
      {
        title: 'Un pilot misurabile',
        body: `Un pilot utile limita partecipanti, durata e decisioni coinvolte. Prima dell’avvio si registra il processo attuale e si decide quali casi restano sempre manuali. Durante la prova si raccolgono tempi, accuratezza, modifiche umane, reclami e richieste di escalation, non soltanto volume generato. Si confrontano casi simili e si annotano cambiamenti operativi che potrebbero influenzare i risultati. Un piccolo gruppo di utenti può rivelare problemi di interfaccia e fiducia che i benchmark non mostrano. Alla fine, il team decide se interrompere, correggere o ampliare, con le motivazioni e i costi di manutenzione già considerati. Un pilot che non ha criteri di stop tende a diventare un’adozione per inerzia; un esperimento delimitato rende più facile imparare senza esporre tutta l’organizzazione.`,
      },
    ],
    keyIdea: 'Il valore reale è il risultato del processo completo, inclusi controlli, manutenzione e persone.',
    commonMistake: 'Stimare il ROI contando contenuti generati invece di misurare risultati corretti e costi di controllo.',
  },
  {
    id: 'futuro',
    number: 11,
    title: 'Tendenze future dell’AI',
    subtitle: 'Capacità emergenti, limiti e scenari possibili',
    minutes: 13,
    sections: [
      {
        title: 'Perché fare previsioni è difficile',
        body: `Le tendenze dell’AI dipendono da progressi scientifici, costi del calcolo, disponibilità di dati, regolazione e adozione sociale. Una curva di crescita recente non dimostra che lo stesso ritmo continuerà: risorse e rendimenti possono cambiare, e i benchmark possono saturarsi senza risolvere problemi pratici. Le previsioni vanno distinte dai risultati osservati e dalle dichiarazioni commerciali. Conviene chiedere quale capacità sia stata misurata, su quali compiti, da chi e con quali limiti. Anche l’impatto economico non si deduce direttamente dalla qualità di una demo: integrazione e cambiamento organizzativo possono richiedere più tempo del modello. Ragionare per scenari è più robusto che scegliere una data precisa per una trasformazione generale: si descrivono ipotesi, segnali da monitorare e decisioni reversibili che preparano a esiti diversi.`,
      },
      {
        title: 'Verso sistemi più multimodali e integrati',
        body: `È plausibile che i sistemi continuino a combinare testo, immagini, audio, video e dati strutturati in interfacce più naturali. Modelli più piccoli e specializzati possono funzionare su dispositivi locali, riducendo latenza e trasferimento di dati quando hardware e qualità lo consentono. Sistemi grandi possono offrire capacità più ampie, ma costi, energia e necessità di controllo rimangono importanti. La multimodalità non equivale a una percezione umana completa: un modello può interpretare male tempi, prospettiva, rumore o contesto. Le interfacce potrebbero passare dalla chat a esperienze miste con strumenti e suggerimenti contestuali; questo aumenta l’importanza di sapere quale componente ha prodotto ogni informazione. Nel futuro prossimo, l’innovazione non sarà soltanto “un modello più grande”: ottimizzazione, dati di qualità, retrieval, hardware efficiente e integrazione sicura possono creare miglioramenti molto pratici.`,
      },
      {
        title: 'Agenti, robotica e delega',
        body: `Gli agenti potrebbero eseguire sequenze più lunghe, coordinare strumenti e assistere flussi di lavoro con minore intervento. La difficoltà non è solo generare un piano: è mantenere lo stato corretto, recuperare da errori, rispettare permessi e comunicare incertezza per molti passaggi consecutivi. Un errore piccolo può propagarsi quando il risultato alimenta la decisione successiva. Per la robotica si aggiungono mondo fisico, sensori imperfetti, ritardi e conseguenze difficili da annullare. Si procede con ambienti di simulazione, test controllati e supervisione, invece di concedere autonomia per semplice entusiasmo. La delega efficace sarà probabilmente graduata: il sistema propone, poi agisce su attività a basso rischio, mentre operazioni critiche restano soggette a conferma e verifica. Le organizzazioni dovranno anche chiarire chi è responsabile quando un flusso automatico coinvolge più fornitori e strumenti.`,
      },
      {
        title: 'AGI: definizioni e incertezza',
        body: `AGI, o intelligenza artificiale generale, non ha una definizione universalmente accettata né una metrica singola. Può indicare sistemi capaci di trasferire conoscenze fra molti domini, svolgere la maggioranza dei compiti cognitivi o adattarsi a contesti nuovi; queste formulazioni non sono equivalenti. Un modello può ottenere risultati elevati su benchmark diversi e rimanere fragile a cambiamenti piccoli, oppure eccellere in linguaggio senza competenza fisica o sociale. Per discutere in modo utile bisogna specificare capacità, autonomia, orizzonte temporale e livello di affidabilità richiesti. La parola “generale” non implica coscienza, intenzioni o comprensione paragonabili a quelle umane. Previsioni su quando arriverà un’AGI hanno grande incertezza e dipendono dalle definizioni adottate. È più concreto prepararsi a capacità osservabili e valutare ogni sistema in base ai rischi del suo impiego.`,
      },
      {
        title: 'Energia, accesso e impatto sociale',
        body: `L’addestramento e l’uso dei modelli richiedono infrastrutture, energia, chip e catene di approvvigionamento; l’efficienza può migliorare, ma la domanda complessiva può crescere con l’adozione. La distribuzione dei benefici dipende da chi possiede i dati, chi controlla i modelli e chi può permettersi di usarli. Strumenti accessibili possono ampliare competenze e servizi, ma possono anche concentrare potere o ridurre la visibilità del lavoro umano. Sistemi generativi rendono più economico produrre contenuti, aumentando sia possibilità creative sia disinformazione e frodi. Servono alfabetizzazione, provenienza dei contenuti, protezione dei diritti e canali di contestazione. Valutare l’impatto sociale significa ascoltare persone coinvolte, non soltanto utenti esperti e dirigenti. Indicatori di accessibilità, consumo, distribuzione degli errori e qualità del lavoro aiutano a guardare oltre la velocità e il ricavo.`,
      },
      {
        title: 'Prepararsi con competenze durevoli',
        body: `Le competenze più trasferibili includono formulare problemi, leggere dati, verificare fonti, comprendere limiti statistici e progettare processi con punti di controllo. Imparare a usare un singolo marchio di modello è utile, ma le interfacce e i nomi cambiano; saper confrontare output e valutare evidenze resta importante. Per professionisti e studenti, una pratica efficace è tenere un registro dei casi in cui l’AI aiuta, fallisce o richiede revisione, poi adattare il flusso invece di forzare ogni attività nel modello. Le organizzazioni possono creare spazi sperimentali protetti e policy semplici, aggiornate con esempi reali. Il futuro non è un esito unico già scritto: le scelte su accesso, regole, investimenti e responsabilità influenzano quali capacità diventano vantaggiose. Essere preparati significa saper imparare, mettere in dubbio risultati convincenti e decidere quando non usare l’AI.`,
      },
      {
        title: 'Un metodo per seguire le tendenze',
        body: `Per valutare una notizia sull’AI, separa la capacità osservata dalla spiegazione e dalla previsione. Cerca il compito preciso, il dataset, il confronto di base, i limiti dichiarati e le condizioni in cui il risultato fallisce. Verifica se il test misura un’attività utile o soltanto una prestazione sul benchmark. Per una previsione, individua le ipotesi: costo del calcolo, disponibilità dei dati, efficienza e velocità di adozione. Poi chiediti quale segnale concreto la renderebbe meno probabile e quali decisioni possono essere aggiornate più avanti. Questo approccio non riduce l’ambizione scientifica; evita che una parola come “autonomo” o “generale” sostituisca una descrizione misurabile. In un settore che cambia rapidamente, la capacità di aggiornare le proprie convinzioni è una competenza tecnica.`,
      },
    ],
    keyIdea: 'Distinguere capacità dimostrate, scenari e promesse rende possibile prepararsi senza false certezze.',
    commonMistake: 'Trattare “AGI” come un traguardo con definizione e data universalmente condivise.',
  },
];

export type QuizQuestion = {
  id: string;
  moduleId: string;
  prompt: string;
  options: string[];
  answer: number;
  explanation: string;
};

export const dailyQuestions: QuizQuestion[] = [
  {
    id: 'daily-1',
    moduleId: 'machine-learning',
    prompt: 'Una rete ottiene risultati eccellenti sui dati di training ma peggiori su casi nuovi. Qual è il rischio più probabile?',
    options: ['Overfitting', 'Tokenizzazione', 'Pooling', 'Calibrazione'],
    answer: 0,
    explanation: 'L’overfitting si verifica quando il modello si adatta troppo ai dati visti e generalizza male.',
  },
  {
    id: 'daily-2',
    moduleId: 'llm',
    prompt: 'Che cosa fa principalmente un LLM autoregressivo durante la generazione?',
    options: ['Verifica ogni frase online', 'Stima il token successivo', 'Calcola una risposta certa', 'Salva i prompt nel training'],
    answer: 1,
    explanation: 'Il modello stima una distribuzione sui token successivi dato il contesto disponibile.',
  },
  {
    id: 'daily-3',
    moduleId: 'prompt',
    prompt: 'Quale elemento rende una richiesta professionale più verificabile?',
    options: ['Più aggettivi', 'Un compito e un formato atteso', 'Un prompt segreto', 'Togliere il contesto'],
    answer: 1,
    explanation: 'Compito, vincoli e formato esplicito rendono più semplice valutare se l’output risponde al bisogno.',
  },
  {
    id: 'daily-4',
    moduleId: 'etica',
    prompt: 'Un’accuracy alta dimostra da sola che un sistema è equo?',
    options: ['Sì, sempre', 'Solo se è un LLM', 'No, occorre analizzare gli errori per gruppi e contesto', 'Sì, se il dataset è grande'],
    answer: 2,
    explanation: 'Le medie possono nascondere disparità; servono analisi e metriche adatte al contesto.',
  },
  {
    id: 'daily-5',
    moduleId: 'agenti',
    prompt: 'Quale controllo è prudente per un agente che invia comunicazioni esterne?',
    options: ['Permessi illimitati', 'Conferma prima dell’invio', 'Nessun log', 'Un loop senza limite'],
    answer: 1,
    explanation: 'La conferma e i permessi minimi riducono il rischio di azioni esterne non volute.',
  },
];

export const finalQuestions: QuizQuestion[] = [
  { id: 'f1', moduleId: 'storia', prompt: 'Quale evento è associato alla formalizzazione del nome “intelligenza artificiale”?', options: ['Seminario di Dartmouth del 1956', 'Pubblicazione del primo iPhone', 'Nascita del web', 'Prima GPU consumer'], answer: 0, explanation: 'Il seminario di Dartmouth del 1956 consolidò il nome e il programma di ricerca dell’AI.' },
  { id: 'f2', moduleId: 'storia', prompt: 'Che cosa caratterizza l’AI simbolica classica?', options: ['Regole e manipolazione di simboli', 'Solo pixel e immagini', 'Solo apprendimento per rinforzo', 'Generazione casuale di frasi'], answer: 0, explanation: 'I sistemi simbolici rappresentano fatti e regole esplicite e li manipolano.' },
  { id: 'f3', moduleId: 'storia', prompt: 'Quale fattore contribuì alla diffusione del deep learning negli anni 2010?', options: ['Dati, GPU e progressi algoritmici', 'La rimozione dei dati', 'L’abbandono delle reti neurali', 'La scomparsa dei benchmark'], answer: 0, explanation: 'La convergenza di dataset più grandi, calcolo accelerato e algoritmi migliorati rese possibili risultati dirompenti.' },
  { id: 'f4', moduleId: 'machine-learning', prompt: 'A cosa serve il set di test tenuto separato?', options: ['A dare feedback a ogni epoca', 'A stimare prestazioni su dati non usati per le scelte', 'A sostituire il training', 'A etichettare automaticamente i dati'], answer: 1, explanation: 'Un test indipendente aiuta a stimare la generalizzazione dopo la selezione del modello.' },
  { id: 'f5', moduleId: 'machine-learning', prompt: 'Quando può essere fuorviante l’accuracy?', options: ['Quando le classi sono molto sbilanciate', 'Quando si usa un computer', 'Quando esiste una validation', 'Quando i dati sono numerici'], answer: 0, explanation: 'Una classe dominante può rendere alta l’accuracy anche se il modello ignora i casi rari importanti.' },
  { id: 'f6', moduleId: 'machine-learning', prompt: 'Nel reinforcement learning, che cosa cerca di massimizzare l’agente?', options: ['La ricompensa cumulativa', 'Il numero di etichette', 'La lunghezza del prompt', 'Il numero di strati'], answer: 0, explanation: 'L’obiettivo è imparare una politica che massimizzi la ricompensa nel tempo.' },
  { id: 'f7', moduleId: 'reti-neurali', prompt: 'Qual è il ruolo del bias in un neurone artificiale?', options: ['Spostare la somma prima dell’attivazione', 'Contare i dati mancanti', 'Scegliere il dataset', 'Ridurre la dimensione delle immagini'], answer: 0, explanation: 'Il bias è un termine additivo che sposta la trasformazione lineare prima dell’attivazione.' },
  { id: 'f8', moduleId: 'reti-neurali', prompt: 'Perché si usa la backpropagation?', options: ['Per calcolare gradienti rispetto ai parametri', 'Per comprimere file audio', 'Per creare etichette', 'Per misurare la latenza'], answer: 0, explanation: 'La backpropagation applica la regola della catena per calcolare come i parametri influenzano la perdita.' },
  { id: 'f9', moduleId: 'reti-neurali', prompt: 'Che cosa può accadere se il learning rate è troppo alto?', options: ['L’ottimizzazione può oscillare o divergere', 'Il modello diventa sempre equo', 'Scompaiono i dati di test', 'La rete smette di usare attivazioni'], answer: 0, explanation: 'Aggiornamenti troppo ampi possono saltare soluzioni utili e rendere instabile l’addestramento.' },
  { id: 'f10', moduleId: 'llm', prompt: 'Che cos’è un token in un modello linguistico?', options: ['Un’unità di testo elaborata dal modello', 'Una prova di verità', 'Una password', 'Un’etichetta di equità'], answer: 0, explanation: 'I token sono unità di testo, spesso parole o parti di parola, che il modello elabora.' },
  { id: 'f11', moduleId: 'llm', prompt: 'A cosa serve la self-attention nel Transformer?', options: ['A pesare relazioni fra posizioni della sequenza', 'A cercare sempre sul web', 'A verificare le fonti', 'A cancellare i dati di training'], answer: 0, explanation: 'L’attenzione confronta rappresentazioni e combina informazioni pertinenti fra posizioni.' },
  { id: 'f12', moduleId: 'llm', prompt: 'Temperatura più alta tende a fare che cosa in generazione?', options: ['Aumentare la variabilità del campionamento', 'Aggiornare i pesi del modello', 'Garantire fatti corretti', 'Aumentare la finestra di contesto'], answer: 0, explanation: 'La temperatura modifica la distribuzione di campionamento, non la conoscenza del modello.' },
  { id: 'f13', moduleId: 'prompt', prompt: 'A cosa servono gli esempi few-shot nel prompt?', options: ['Mostrare il formato o il compito con esempi', 'Addestrare permanentemente il modello', 'Autorizzare l’accesso ai dati', 'Garantire l’assenza di bias'], answer: 0, explanation: 'Gli esempi contestuali orientano il modello per la richiesta corrente, senza aggiornare i pesi.' },
  { id: 'f14', moduleId: 'prompt', prompt: 'Perché validare uno schema JSON prodotto dal modello?', options: ['Per controllare campi e tipi richiesti', 'Per aumentare i parametri', 'Per cambiare la temperatura', 'Per eliminare il training'], answer: 0, explanation: 'L’output va verificato dal software; la sola istruzione non garantisce un formato valido.' },
  { id: 'f15', moduleId: 'prompt', prompt: 'Qual è una difesa più robusta dalla prompt injection?', options: ['Permessi minimi e validazione degli strumenti', 'Nascondere una frase nel system prompt', 'Usare solo testi lunghi', 'Fidarsi dei documenti recuperati'], answer: 0, explanation: 'Controlli applicativi e permessi limitati riducono ciò che un input ostile può provocare.' },
  { id: 'f16', moduleId: 'vision', prompt: 'Che cosa fa una convoluzione in una CNN?', options: ['Applica filtri locali ai pixel', 'Traduce parlato in testo', 'Calcola ricompense future', 'Crea una password'], answer: 0, explanation: 'I filtri convoluzionali rilevano configurazioni locali riutilizzando i pesi nello spazio.' },
  { id: 'f17', moduleId: 'vision', prompt: 'Da che cosa parte tipicamente la generazione con diffusione?', options: ['Rumore progressivamente trasformato', 'Una diagnosi confermata', 'Una lista di regole legali', 'Un set di etichette già corrette'], answer: 0, explanation: 'Il processo di generazione parte da rumore e lo trasforma iterativamente in un campione.' },
  { id: 'f18', moduleId: 'vision', prompt: 'Perché un classificatore può imparare un indizio spurio?', options: ['Le correlazioni nei dati possono non rappresentare la causa', 'I pixel sono sempre casuali', 'Le CNN non hanno pesi', 'La metrica impedisce ogni errore'], answer: 0, explanation: 'Il modello può sfruttare scorciatoie correlate alle etichette nei dati di training.' },
  { id: 'f19', moduleId: 'audio', prompt: 'Che cosa misura il word error rate?', options: ['Sostituzioni, cancellazioni e inserimenti in una trascrizione', 'La qualità del microfono in euro', 'Il tempo di training', 'Il numero di speaker autorizzati'], answer: 0, explanation: 'WER confronta parole di riferimento e trascritte attraverso errori di sostituzione, cancellazione e inserimento.' },
  { id: 'f20', moduleId: 'audio', prompt: 'Quale precauzione è importante per la clonazione vocale?', options: ['Autorizzazione e disclosure della voce sintetica', 'Aumentare il volume', 'Eliminare ogni revisione', 'Usare la voce come unica credenziale'], answer: 0, explanation: 'Consenso, disclosure e limiti d’accesso aiutano a prevenire impersonificazione e abuso.' },
  { id: 'f21', moduleId: 'agenti', prompt: 'Qual è il principio del minimo privilegio?', options: ['Concedere soltanto le autorizzazioni necessarie', 'Concedere accesso amministratore', 'Non registrare le azioni', 'Consentire cicli senza limiti'], answer: 0, explanation: 'I permessi limitati riducono l’impatto di errori e input ostili.' },
  { id: 'f22', moduleId: 'agenti', prompt: 'Quando è opportuno fermare e chiedere conferma a un agente?', options: ['Prima di un’azione esterna irreversibile', 'Dopo ogni parola generata', 'Mai', 'Solo quando la rete è veloce'], answer: 0, explanation: 'Azioni con effetti esterni o difficili da annullare richiedono autorizzazione esplicita.' },
  { id: 'f23', moduleId: 'agenti', prompt: 'Perché impostare un limite di iterazioni?', options: ['Per contenere loop, costi e propagazione degli errori', 'Per aumentare i dati di training', 'Per assicurare AGI', 'Per rimuovere i controlli'], answer: 0, explanation: 'Limiti e criteri di arresto impediscono cicli e costi imprevedibili.' },
  { id: 'f24', moduleId: 'etica', prompt: 'Che cosa può nascondere una metrica media elevata?', options: ['Errori concentrati su alcuni gruppi', 'Ogni forma di costo', 'La versione del modello', 'La dimensione dello schermo'], answer: 0, explanation: 'Metriche aggregate possono mascherare disparità fra gruppi e sottogruppi.' },
  { id: 'f25', moduleId: 'etica', prompt: 'Qual è l’approccio generale dell’AI Act europeo?', options: ['Basato sul rischio', 'Solo basato sui ricavi', 'Identico per ogni uso', 'Facoltativo per definizione'], answer: 0, explanation: 'Il Regolamento (UE) 2024/1689 prevede obblighi distinti in base a pratiche e livelli di rischio.' },
  { id: 'f26', moduleId: 'business', prompt: 'Qual è un buon primo criterio per scegliere un caso d’uso AI?', options: ['Valore misurabile e rischio gestibile', 'Il modello più grande disponibile', 'La maggiore quantità di dati personali', 'Una demo senza baseline'], answer: 0, explanation: 'Un caso d’uso pilota dovrebbe avere obiettivo misurabile, dati disponibili e rischi controllabili.' },
  { id: 'f27', moduleId: 'business', prompt: 'Che cosa dovrebbe includere il costo totale di un sistema AI?', options: ['Integrazione, revisione, sicurezza e manutenzione', 'Solo il prezzo per token', 'Solo il costo del prototipo', 'Solo i ricavi attesi'], answer: 0, explanation: 'Il TCO include i costi operativi e di controllo lungo il ciclo di vita.' },
  { id: 'f28', moduleId: 'futuro', prompt: 'Perché “AGI” è difficile da misurare con una singola metrica?', options: ['Non esiste una definizione universalmente condivisa', 'È già una funzione matematica precisa', 'Dipende solo dalla velocità', 'Si misura solo con immagini'], answer: 0, explanation: 'Definizioni diverse di generalità e adattabilità portano a metriche e conclusioni diverse.' },
  { id: 'f29', moduleId: 'futuro', prompt: 'Perché una crescita recente dei benchmark non garantisce lo stesso ritmo futuro?', options: ['Risorse e rendimenti possono cambiare', 'I benchmark sono sempre inutili', 'I modelli non usano dati', 'L’hardware non conta'], answer: 0, explanation: 'Trend, costi, dati e rendimenti non restano necessariamente costanti.' },
  { id: 'f30', moduleId: 'futuro', prompt: 'Quale competenza resta utile anche se cambiano i fornitori?', options: ['Verificare evidenze e definire problemi', 'Memorizzare un singolo prompt', 'Fidarsi di qualunque output', 'Usare solo una metrica'], answer: 0, explanation: 'Valutazione critica, formulazione del problema e verifica si trasferiscono fra strumenti diversi.' },
];

export const glossary: { term: string; letter: string; definition: string }[] = [
  { term: 'Agente AI', letter: 'A', definition: 'Sistema che osserva informazioni, sceglie azioni e può usare strumenti per perseguire un obiettivo definito.' },
  { term: 'Allucinazione', letter: 'A', definition: 'Output plausibile ma non supportato o non corretto rispetto alle evidenze disponibili.' },
  { term: 'Attention', letter: 'A', definition: 'Meccanismo che pesa le relazioni fra elementi di una sequenza per combinarne le informazioni.' },
  { term: 'Backpropagation', letter: 'B', definition: 'Metodo che calcola gradienti nella rete, propagando all’indietro l’influenza della perdita sui parametri.' },
  { term: 'Bias', letter: 'B', definition: 'Termine additivo di un neurone; nel contesto etico, distorsione sistematica che può produrre impatti diseguali.' },
  { term: 'Calibrazione', letter: 'C', definition: 'Corrispondenza fra probabilità stimate e frequenze effettive degli eventi.' },
  { term: 'CNN', letter: 'C', definition: 'Rete neurale convoluzionale che applica filtri locali, spesso usata nell’elaborazione delle immagini.' },
  { term: 'Dataset', letter: 'D', definition: 'Collezione organizzata di esempi usata per training, validazione o test di un sistema.' },
  { term: 'Embedding', letter: 'E', definition: 'Vettore numerico che rappresenta un token o un elemento in uno spazio appreso.' },
  { term: 'Few-shot', letter: 'F', definition: 'Tecnica che fornisce pochi esempi nel prompt per orientare il compito senza modificare i pesi.' },
  { term: 'Fine-tuning', letter: 'F', definition: 'Ulteriore addestramento di un modello pre-addestrato su dati o compiti più specifici.' },
  { term: 'Generative AI', letter: 'G', definition: 'Famiglia di sistemi che genera nuovi contenuti, come testo, immagini, audio o codice.' },
  { term: 'Gradient descent', letter: 'G', definition: 'Procedura di ottimizzazione che aggiorna i parametri muovendosi verso una perdita minore.' },
  { term: 'Hallucination', letter: 'H', definition: 'Termine inglese per un output plausibile ma non supportato dalle evidenze disponibili.' },
  { term: 'In-context learning', letter: 'I', definition: 'Uso delle istruzioni ed esempi nel contesto corrente per svolgere un compito, senza aggiornare i pesi.' },
  { term: 'Jensen-Shannon divergence', letter: 'J', definition: 'Misura simmetrica della differenza fra distribuzioni di probabilità, usata in analisi e machine learning.' },
  { term: 'K-fold cross-validation', letter: 'K', definition: 'Metodo di valutazione che divide i dati in K parti e ripete il test usando ogni parte a turno.' },
  { term: 'LLM', letter: 'L', definition: 'Large Language Model: modello linguistico addestrato su grandi collezioni di testo per stimare token.' },
  { term: 'Machine Learning', letter: 'M', definition: 'Metodi che apprendono regolarità dai dati per svolgere previsioni o decisioni.' },
  { term: 'NLP', letter: 'N', definition: 'Natural Language Processing: metodi per analizzare, comprendere o generare linguaggio umano.' },
  { term: 'Overfitting', letter: 'O', definition: 'Adattamento eccessivo ai dati di training, con prestazioni peggiori su esempi nuovi.' },
  { term: 'Prompt injection', letter: 'P', definition: 'Tentativo di far trattare contenuti non attendibili come istruzioni, superando il comportamento previsto.' },
  { term: 'Quantizzazione', letter: 'Q', definition: 'Riduzione della precisione numerica dei parametri per diminuire dimensioni o costo di inferenza.' },
  { term: 'RAG', letter: 'R', definition: 'Retrieval-Augmented Generation: recupero di fonti pertinenti da fornire come contesto a un modello generativo.' },
  { term: 'Reinforcement Learning', letter: 'R', definition: 'Apprendimento in cui un agente interagisce con un ambiente e ottimizza ricompense nel tempo.' },
  { term: 'Self-attention', letter: 'S', definition: 'Operazione Transformer con cui ogni posizione valuta e combina informazioni da altre posizioni.' },
  { term: 'Token', letter: 'T', definition: 'Unità testuale elaborata dal modello, come una parola, una parte di parola o un segno.' },
  { term: 'Transformer', letter: 'T', definition: 'Architettura basata sull’attenzione, centrale nei modelli linguistici moderni.' },
  { term: 'Unsupervised learning', letter: 'U', definition: 'Apprendimento che individua strutture nei dati senza etichette esplicite per ogni esempio.' },
  { term: 'Validation set', letter: 'V', definition: 'Dati separati usati per confrontare modelli e impostazioni durante lo sviluppo.' },
  { term: 'Weight (peso)', letter: 'W', definition: 'Parametro numerico che determina l’influenza di un ingresso o di una connessione nella rete.' },
  { term: 'XAI', letter: 'X', definition: 'Explainable AI: metodi e pratiche che aiutano a comprendere e valutare il comportamento di un sistema.' },
  { term: 'YOLO', letter: 'Y', definition: 'Famiglia di modelli di object detection che individua oggetti in un’immagine in un singolo passaggio.' },
  { term: 'Zero-shot', letter: 'Z', definition: 'Svolgimento di un compito senza esempi specifici nel prompt, usando istruzioni e conoscenze apprese.' },
];

export function getDailyQuestions(dateKey: string): QuizQuestion[] {
  const [year, month, day] = dateKey.split('-').map(Number);
  const dayNumber = Math.floor(new Date(year, month - 1, day).getTime() / 86_400_000);
  return Array.from({ length: 5 }, (_, index) => finalQuestions[(dayNumber * 5 + index * 7) % finalQuestions.length]);
}
