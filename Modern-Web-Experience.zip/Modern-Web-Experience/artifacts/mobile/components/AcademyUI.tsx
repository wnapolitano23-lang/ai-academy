import React, { type ReactNode } from 'react';
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type PressableProps,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

export function Page({ children }: { children: ReactNode }) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentInsetAdjustmentBehavior="automatic"
        contentContainerStyle={{
          paddingHorizontal: 21,
          paddingTop: Platform.OS === 'web' ? 67 : Math.max(insets.top, 10) + 8,
          paddingBottom: Platform.OS === 'web' ? 34 : 26,
        }}
      >
        {children}
      </ScrollView>
    </View>
  );
}

export function Kicker({ children }: { children: ReactNode }) {
  const colors = useColors();
  return <Text style={[styles.kicker, { color: colors.primary }]}>{children}</Text>;
}

export function Heading({ children, subtitle }: { children: ReactNode; subtitle?: string }) {
  const colors = useColors();
  return (
    <View style={styles.headingWrap}>
      <Text style={[styles.heading, { color: colors.foreground }]}>{children}</Text>
      {subtitle ? (
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{subtitle}</Text>
      ) : null}
    </View>
  );
}

export function Panel({
  children,
  style,
}: {
  children: ReactNode;
  style?: object;
}) {
  const colors = useColors();
  return (
    <View style={[styles.panel, { backgroundColor: colors.card, borderColor: colors.border }, style]}>
      {children}
    </View>
  );
}

export function ActionButton({
  label,
  onPress,
  variant = 'primary',
  disabled = false,
  ...props
}: PressableProps & { label: string; variant?: 'primary' | 'secondary' | 'quiet' }) {
  const colors = useColors();
  const backgroundColor =
    variant === 'primary'
      ? colors.primary
      : variant === 'secondary'
        ? colors.secondary
        : 'transparent';
  const color =
    variant === 'primary'
      ? colors.primaryForeground
      : variant === 'secondary'
        ? colors.secondaryForeground
        : colors.primary;
  return (
    <Pressable
      {...props}
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor, opacity: disabled ? 0.45 : pressed ? 0.72 : 1 },
        variant === 'quiet' && { borderWidth: 1, borderColor: colors.border },
        props.style as object,
      ]}
    >
      <Text style={[styles.buttonText, { color }]}>{label}</Text>
    </Pressable>
  );
}

export function ProgressBar({
  value,
  label,
}: {
  value: number;
  label?: string;
}) {
  const colors = useColors();
  const bounded = Math.max(0, Math.min(100, value));
  return (
    <View>
      {label ? (
        <View style={styles.progressMeta}>
          <Text style={[styles.smallLabel, { color: colors.mutedForeground }]}>{label}</Text>
          <Text style={[styles.smallLabel, { color: colors.foreground }]}>{Math.round(bounded)}%</Text>
        </View>
      ) : null}
      <View style={[styles.progressTrack, { backgroundColor: colors.muted }]}>
        <View style={[styles.progressFill, { width: `${bounded}%`, backgroundColor: colors.primary }]} />
      </View>
    </View>
  );
}

export function Chip({ children, active = false }: { children: ReactNode; active?: boolean }) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.chip,
        {
          backgroundColor: active ? colors.accent : colors.secondary,
          borderColor: active ? colors.primary : colors.border,
        },
      ]}
    >
      <Text style={[styles.chipText, { color: active ? colors.accentForeground : colors.mutedForeground }]}>
        {children}
      </Text>
    </View>
  );
}

export function BodyText({ children, style }: { children: ReactNode; style?: object }) {
  const colors = useColors();
  return <Text style={[styles.body, { color: colors.secondaryForeground }, style]}>{children}</Text>;
}

export function Divider() {
  const colors = useColors();
  return <View style={[styles.divider, { backgroundColor: colors.border }]} />;
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  kicker: { fontSize: 11, letterSpacing: 1.8, textTransform: 'uppercase', fontFamily: 'Inter_700Bold' },
  headingWrap: { gap: 7, marginTop: 7, marginBottom: 22 },
  heading: { fontFamily: 'Inter_700Bold', fontSize: 29, lineHeight: 35, letterSpacing: -0.8 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21 },
  panel: { borderWidth: 1, borderRadius: 20, padding: 17, marginBottom: 13 },
  button: {
    minHeight: 50,
    borderRadius: 15,
    paddingHorizontal: 17,
    paddingVertical: 13,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: { fontFamily: 'Inter_700Bold', fontSize: 14, textAlign: 'center' },
  progressMeta: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  smallLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  progressTrack: { height: 8, borderRadius: 9, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 9 },
  chip: { borderRadius: 30, borderWidth: 1, paddingHorizontal: 11, paddingVertical: 6, alignSelf: 'flex-start' },
  chipText: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  body: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 22 },
  divider: { height: StyleSheet.hairlineWidth, marginVertical: 14 },
});
