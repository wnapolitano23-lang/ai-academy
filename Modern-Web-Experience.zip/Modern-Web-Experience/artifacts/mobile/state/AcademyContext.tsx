import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';

const STORAGE_KEY = 'ai-academy-progress-v1';

type DailyAnswer = { choice: number; correct: boolean };
type AcademyState = {
  completedModules: string[];
  xp: number;
  dailyRecords: Record<string, Record<string, DailyAnswer>>;
  certificateName: string;
  examAttempts: number;
  bestExamScore: number | null;
  lastExamScore: number | null;
  examXpClaimed: boolean;
};

type AcademyContextValue = AcademyState & {
  ready: boolean;
  completeModule: (id: string) => void;
  answerDaily: (date: string, id: string, choice: number, correct: boolean) => void;
  setCertificateName: (name: string) => void;
  submitExam: (score: number, name: string) => void;
};

const initialState: AcademyState = {
  completedModules: [],
  xp: 0,
  dailyRecords: {},
  certificateName: '',
  examAttempts: 0,
  bestExamScore: null,
  lastExamScore: null,
  examXpClaimed: false,
};

const AcademyContext = createContext<AcademyContextValue | null>(null);

export function AcademyProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AcademyState>(initialState);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (!active) return;
        if (stored) {
          try {
            const parsed = JSON.parse(stored) as Partial<AcademyState>;
            setState({ ...initialState, ...parsed });
          } catch {
            setState(initialState);
          }
        }
      })
      .catch(() => {
        if (active) setState(initialState);
      })
      .finally(() => {
        if (active) setReady(true);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (ready) {
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state)).catch(() => undefined);
    }
  }, [ready, state]);

  const completeModule = useCallback((id: string) => {
    setState((current) => {
      if (current.completedModules.includes(id)) return current;
      return {
        ...current,
        completedModules: [...current.completedModules, id],
        xp: current.xp + 50,
      };
    });
  }, []);

  const answerDaily = useCallback(
    (date: string, id: string, choice: number, correct: boolean) => {
      setState((current) => {
        if (current.dailyRecords[date]?.[id]) return current;
        return {
          ...current,
          xp: current.xp + (correct ? 10 : 0),
          dailyRecords: {
            ...current.dailyRecords,
            [date]: {
              ...current.dailyRecords[date],
              [id]: { choice, correct },
            },
          },
        };
      });
    },
    [],
  );

  const setCertificateName = useCallback((name: string) => {
    setState((current) => ({ ...current, certificateName: name }));
  }, []);

  const submitExam = useCallback((score: number, name: string) => {
    setState((current) => ({
      ...current,
      certificateName: name.trim() || current.certificateName,
      examAttempts: current.examAttempts + 1,
      bestExamScore:
        current.bestExamScore === null
          ? score
          : Math.max(current.bestExamScore, score),
      lastExamScore: score,
      examXpClaimed: true,
      xp: current.xp + (current.examXpClaimed ? 0 : 100),
    }));
  }, []);

  const value = useMemo(
    () => ({
      ...state,
      ready,
      completeModule,
      answerDaily,
      setCertificateName,
      submitExam,
    }),
    [state, ready, completeModule, answerDaily, setCertificateName, submitExam],
  );

  return <AcademyContext.Provider value={value}>{children}</AcademyContext.Provider>;
}

export function useAcademy() {
  const context = useContext(AcademyContext);
  if (!context) throw new Error('useAcademy must be used inside AcademyProvider');
  return context;
}
