/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#EBF5FF',
    tint: '#56F1CE',

    // Core surfaces
    background: '#080D17',
    foreground: '#EBF5FF',

    // Cards / elevated surfaces
    card: '#111B29',
    cardForeground: '#EBF5FF',

    // Primary action color (buttons, links, active states)
    primary: '#56F1CE',
    primaryForeground: '#061511',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#19273A',
    secondaryForeground: '#D7E3F1',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#172436',
    mutedForeground: '#91A2B6',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#15343A',
    accentForeground: '#75F4D9',

    // Destructive actions (delete, error states)
    destructive: '#FF7887',
    destructiveForeground: '#20070A',

    // Borders and input outlines
    border: '#26364A',
    input: '#26364A',
  },

  dark: {
    text: '#EBF5FF',
    tint: '#56F1CE',
    background: '#080D17',
    foreground: '#EBF5FF',
    card: '#111B29',
    cardForeground: '#EBF5FF',
    primary: '#56F1CE',
    primaryForeground: '#061511',
    secondary: '#19273A',
    secondaryForeground: '#D7E3F1',
    muted: '#172436',
    mutedForeground: '#91A2B6',
    accent: '#15343A',
    accentForeground: '#75F4D9',
    destructive: '#FF7887',
    destructiveForeground: '#20070A',
    border: '#26364A',
    input: '#26364A',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 18,
};

export default colors;
